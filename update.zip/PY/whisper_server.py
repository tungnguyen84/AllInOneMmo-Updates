# -*- coding: utf-8 -*-
"""
whisper_server.py
Persistent Whisper server mode:
- Load model 1 lần, giữ warm trong GPU.
- Nhận job qua stdin (JSON-line), trả kết quả qua stdout (JSON-line).
- Tránh cold-start 10-15s mỗi lần transcribe.

Protocol:
  → stdin:  {"cmd":"transcribe","input_audio":"...","output_ass":"...","language":"vi",...}
  → stdout: {"status":"ok","output_ass":"path","lines":42}
  → stdout: {"status":"error","message":"..."}
  
  Special commands:
  → {"cmd":"ping"}          → {"status":"pong"}
  → {"cmd":"shutdown"}      → exits process
"""

import os, sys, json, gc, traceback, time
from typing import List, Tuple

# --- UTF-8 ---
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="ignore")
    except:
        pass

def log(msg: str):
    """Log ra stderr (không lẫn với JSON output trên stdout)."""
    try:
        print(msg, file=sys.stderr, flush=True)
    except:
        pass

def respond(data: dict):
    """Ghi JSON-line ra stdout cho C# đọc."""
    try:
        print(json.dumps(data, ensure_ascii=False), flush=True)
    except:
        pass

# --- Setup CUDA ---
def setup_cuda_environment_windows():
    if os.name != "nt":
        return
    try:
        import site
        base_candidates = []
        for sp in site.getsitepackages():
            if "site-packages" in sp:
                base_candidates.append(os.path.join(sp, "nvidia"))
        p = os.environ.get("PATH", "")
        for b in base_candidates:
            for sub in ["cudnn/bin", "cublas/bin", "cuda_runtime/bin", "cufft/bin", "curand/bin"]:
                d = os.path.join(b, sub)
                if os.path.isdir(d) and d not in p:
                    os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
                    p = os.environ["PATH"]
        for d in [r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12\bin",
                   r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11\bin"]:
            if os.path.isdir(d) and d not in p:
                os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
                p = os.environ["PATH"]
    except:
        pass

setup_cuda_environment_windows()

import numpy as np

try:
    import torch
except ImportError:
    torch = None

try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None
    log("[ERR] faster-whisper chưa cài!")


# --- Import utility functions từ whisper_subtitle.py ---
def hex_to_rgb(hex_str: str):
    s = hex_str.strip().lstrip("#")
    if len(s) == 3:
        s = "".join(ch * 2 for ch in s)
    if len(s) != 6:
        return (255, 255, 255)
    try:
        return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    except:
        return (255, 255, 255)

def seconds_to_ass_time(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    cs = int(round((t - int(t)) * 100))
    if cs == 100:
        cs = 0; s += 1
        if s == 60:
            s = 0; m += 1
            if m == 60:
                m = 0; h += 1
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

def seconds_to_srt_time(t: float) -> str:
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms >= 1000:
        ms = 0; s += 1
        if s == 60:
            s = 0; m += 1
            if m == 60:
                m = 0; h += 1
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def rgb_to_ass(r, g, b):
    return f"&H00{b:02X}{g:02X}{r:02X}"

def rgba_box_color(r, g, b, alpha_percent):
    alpha_percent = max(0, min(alpha_percent, 100))
    a = 255 - int(255 * (alpha_percent / 100.0))
    return f"&H{a:02X}{b:02X}{g:02X}{r:02X}"


# --- Model Management ---
_model = None
_model_id = None

def load_model(model_id: str, device: str = "auto", compute_type: str = "float16", device_index: int = 0):
    global _model, _model_id

    if _model is not None and _model_id == model_id:
        log(f"[SERVER] Model đã sẵn sàng (warm): {model_id}")
        return _model

    # Unload model cũ
    if _model is not None:
        del _model
        gc.collect()
        if torch and torch.cuda.is_available():
            torch.cuda.empty_cache()

    log(f"[SERVER] Loading model: {model_id} (device={device}, compute={compute_type}, gpu={device_index})")

    if WhisperModel is None:
        raise RuntimeError("faster-whisper not installed")

    if device in ("auto", "cuda"):
        candidates = []
        if compute_type not in ("auto", ""):
            candidates.append(compute_type)
        for ct in ["float16", "int8_float16", "int8"]:
            if ct not in candidates:
                candidates.append(ct)

        for ct in candidates:
            try:
                log(f"[SERVER] Thử GPU:{device_index} ({ct})...")
                m = WhisperModel(model_id, device="cuda", device_index=device_index, compute_type=ct)
                # Quick health check
                dummy = np.zeros(16000, dtype=np.float32)
                list(m.transcribe(dummy, beam_size=1))
                log(f"[SERVER] ✅ GPU:{device_index} ({ct}) OK")
                _model = m
                _model_id = model_id
                return _model
            except Exception as e:
                log(f"[SERVER] ⚠️ GPU ({ct}) lỗi: {e}")

        log("[SERVER] GPU thất bại, chuyển CPU")

    try:
        _model = WhisperModel(model_id, device="cpu", compute_type="int8")
        _model_id = model_id
        log("[SERVER] ✅ CPU model loaded")
        return _model
    except Exception as e:
        raise RuntimeError(f"Không thể load model: {e}")


def transcribe_job(job: dict) -> dict:
    """Xử lý 1 job transcribe."""
    t0 = time.time()

    input_audio = job.get("input_audio", "")
    output_ass = job.get("output_ass", "")
    output_srt = job.get("output_srt", "")
    model_id = job.get("model_id", "medium")
    model_dir = job.get("model_dir", "")
    device = job.get("device", "auto")
    compute_type = job.get("compute_type", "float16")
    device_index = job.get("device_index", 0)
    language = job.get("language", "vi")
    beam_size = job.get("beam_size", 2)
    batch_size = job.get("batch_size", 16)
    vad_filter = job.get("vad_filter", True)
    word_timestamps = job.get("word_timestamps", True)
    words_per_line = job.get("words_per_line", 8)
    overlap = job.get("overlap", 0.3)

    if not input_audio or not os.path.isfile(input_audio):
        return {"status": "error", "message": f"File audio không tồn tại: {input_audio}"}
    if not output_ass:
        return {"status": "error", "message": "Thiếu output_ass path"}

    # Resolve model_id from model_dir
    if model_dir and os.path.isfile(os.path.join(model_dir, "model.bin")):
        model_id = model_dir
    elif model_dir:
        os.environ["HF_HOME"] = model_dir
        os.environ["CT2_CACHES_DIR"] = model_dir

    # Load/reuse model
    model = load_model(model_id, device, compute_type, device_index)

    # Transcribe (model stays warm!)
    log(f"[SERVER] Transcribing: {input_audio}")
    segments, _ = model.transcribe(
        input_audio,
        language=language if language != "auto" else None,
        vad_filter=vad_filter,
        beam_size=beam_size,
        word_timestamps=word_timestamps,
        batch_size=batch_size,
    )
    segments = list(segments)

    # Build subtitle list
    final_subs = []

    def flush_buffer(buf, subs_list, ovl):
        if not buf:
            return
        start = buf[0]["start"]
        end = buf[-1]["end"]
        text = " ".join(w["word"].strip() for w in buf)
        if subs_list and ovl > 0:
            prev_end = subs_list[-1][1]
            start = max(subs_list[-1][0] + 0.1, min(start, prev_end - ovl))
        subs_list.append((start, end, text))

    for seg in segments:
        if not getattr(seg, "words", None):
            final_subs.append((seg.start, seg.end, seg.text.strip()))
            continue
        buffer = []
        for word in seg.words:
            buffer.append({"start": word.start, "end": word.end, "word": word.word})
            if len(buffer) >= words_per_line:
                flush_buffer(buffer, final_subs, overlap)
                buffer = []
        flush_buffer(buffer, final_subs, overlap)

    # Write ASS
    os.makedirs(os.path.dirname(output_ass) or ".", exist_ok=True)
    write_ass(final_subs, job, output_ass)

    # Write SRT (optional)
    if output_srt:
        os.makedirs(os.path.dirname(output_srt) or ".", exist_ok=True)
        write_srt(final_subs, output_srt)

    elapsed = time.time() - t0
    log(f"[SERVER] ✅ Done in {elapsed:.1f}s, {len(final_subs)} lines")

    return {
        "status": "ok",
        "output_ass": output_ass,
        "output_srt": output_srt if output_srt else None,
        "lines": len(final_subs),
        "elapsed_seconds": round(elapsed, 2)
    }


def write_ass(subs, job, output_ass):
    """Ghi file ASS."""
    font_name = job.get("font_name", "Arial")
    font_size = job.get("font_size", 30)
    font_color = job.get("font_color", "#FFFFFF")
    outline_width = job.get("outline_width", 2)
    outline_color = job.get("outline_color", "#000000")
    background_color = job.get("background_color", "#000000")
    bg_box = job.get("bg_box", False)
    background_alpha_percent = job.get("background_alpha_percent", 0)
    position_tag = job.get("position_tag", "bottom")
    margin_top = job.get("margin_top", 50)
    margin_bottom = job.get("margin_bottom", 50)

    font_rgb = hex_to_rgb(font_color)
    outline_rgb = hex_to_rgb(outline_color)
    bg_rgb = hex_to_rgb(background_color)

    primary = rgb_to_ass(*font_rgb)
    secondary = primary
    outline_ass = rgb_to_ass(*outline_rgb)

    if bg_box and background_alpha_percent > 0:
        back = rgba_box_color(*bg_rgb, background_alpha_percent)
        border_style = 3
        outline_for_style = back
    else:
        back = "&HFF000000"
        border_style = 1
        outline_for_style = outline_ass

    pos = (position_tag or "bottom").lower()
    if "top" in pos:
        alignment = 8
        margin_v = margin_top
    elif "center" in pos:
        alignment = 5
        margin_v = max(margin_top, margin_bottom)
    else:
        alignment = 2
        margin_v = margin_bottom

    margin_v = max(0, int(margin_v))
    margin_v_str = f"{margin_v:04d}"

    header = f"""[Script Info]
; Generated by whisper_server.py (warm model)
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{font_name},{font_size},{primary},{secondary},{outline_for_style},{back},0,0,0,0,100,100,0,0,{border_style},{outline_width},1,{alignment},0000,0000,{margin_v_str},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    lines = [header]
    for start, end, text in subs:
        s_str = seconds_to_ass_time(start)
        e_str = seconds_to_ass_time(end)
        safe = (text or "").replace("\\n", " ").replace("\n", " ").replace("\r", " ")
        safe = safe.replace("{", "(").replace("}", ")")
        lines.append(f"Dialogue: 0,{s_str},{e_str},Default,,0000,0000,{margin_v_str},,{safe}\n")

    with open(output_ass, "w", encoding="utf-8-sig") as f:
        f.writelines(lines)
    log(f"[ASS] Wrote: {output_ass}")


def write_srt(subs, output_srt):
    blocks = []
    for i, (start, end, text) in enumerate(subs, 1):
        s = seconds_to_srt_time(start)
        e = seconds_to_srt_time(end)
        safe = (text or "").replace("\r", "").strip()
        blocks.append(f"{i}\n{s} --> {e}\n{safe}")
    with open(output_srt, "w", encoding="utf-8-sig") as f:
        f.write("\n\n".join(blocks) + "\n")
    log(f"[SRT] Wrote: {output_srt}")


# =========================
#  Main Server Loop
# =========================
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_dir", default="", help="Thư mục chứa model local")
    parser.add_argument("--model_id", default="medium")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--device_index", type=int, default=0)
    parser.add_argument("--compute_type", default="float16")
    args = parser.parse_args()

    # Resolve model_id
    if args.model_dir and os.path.isfile(os.path.join(args.model_dir, "model.bin")):
        args.model_id = args.model_dir

    # Pre-load model (warm up)
    log("[SERVER] 🚀 Whisper Server starting...")
    try:
        load_model(args.model_id, args.device, args.compute_type, args.device_index)
        log("[SERVER] ✅ Model warm. Waiting for jobs on stdin (JSON-line)...")
        respond({"status": "ready", "model": args.model_id})
    except Exception as e:
        log(f"[SERVER] ❌ Failed to load model: {e}")
        respond({"status": "error", "message": str(e)})
        sys.exit(1)

    # Main loop: read JSON-line from stdin
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            job = json.loads(line)
        except json.JSONDecodeError as e:
            respond({"status": "error", "message": f"Invalid JSON: {e}"})
            continue

        cmd = job.get("cmd", "transcribe")

        if cmd == "ping":
            respond({"status": "pong"})
        elif cmd == "shutdown":
            log("[SERVER] Shutting down...")
            respond({"status": "shutdown"})
            break
        elif cmd == "transcribe":
            try:
                result = transcribe_job(job)
                respond(result)
            except Exception as e:
                log(f"[SERVER] ❌ Error: {e}")
                traceback.print_exc(file=sys.stderr)
                respond({"status": "error", "message": str(e)})
        else:
            respond({"status": "error", "message": f"Unknown command: {cmd}"})

    # Cleanup
    if _model is not None:
        del _model
        gc.collect()
        if torch and torch.cuda.is_available():
            torch.cuda.empty_cache()

    log("[SERVER] 👋 Server stopped.")
