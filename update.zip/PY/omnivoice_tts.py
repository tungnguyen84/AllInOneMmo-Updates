#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
OmniVoice TTS local inference script.
Called by C# via subprocess.

Supports two modes:
  1. One-shot: python omnivoice_tts.py --config config.json
  2. Server:   python omnivoice_tts.py --server --model-path <path>

Dependencies: omnivoice (k2-fsa/OmniVoice), torch, torchaudio, soundfile
"""

import argparse
import json
import sys
import os
import numpy as np

# Force torchaudio to use soundfile backend (torchcodec has DLL issues)
os.environ["TORCHAUDIO_USE_BACKEND_V2"] = "0"


def load_model(model_path):
    """Load OmniVoice model."""
    import torch
    import torchaudio
    try:
        torchaudio.set_audio_backend("soundfile")
    except Exception:
        pass

    from omnivoice import OmniVoice

    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    print(f"[OmniVoice] Device: {device}, dtype: {dtype}", flush=True)
    print(f"[OmniVoice] Loading model from {model_path}...", flush=True)

    model = OmniVoice.from_pretrained(
        model_path,
        device_map=device,
        dtype=dtype
    )

    print("[OmniVoice] Model loaded successfully!", flush=True)
    return model


def run_inference_with_model(model, args):
    """Run inference with a pre-loaded model."""
    import torch
    import torchaudio

    mode = args['mode']
    text = args['text'].strip()
    output_path = args['output']

    # Audio params
    speed = float(args.get('speed', 1.0))
    steps = int(args.get('steps', 32))
    guidance_scale = float(args.get('guidance_scale', 2.0))
    denoise = bool(args.get('denoise', True))

    print(f"[OmniVoice] Mode: {mode}", flush=True)
    print(f"[OmniVoice] Text: {text[:80]}...", flush=True)
    print(f"[OmniVoice] Params: speed={speed}, steps={steps}, cfg={guidance_scale}", flush=True)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    try:
        gen_args = {
            "text": text,
            "num_step": steps,
            "speed": speed,
            "guidance_scale": guidance_scale,
            "denoise": denoise
        }

        language_id = args.get('language_id', 'auto')
        if language_id and language_id != 'auto':
            gen_args["language"] = language_id

        duration = float(args.get('duration', 0))
        if duration > 0:
            gen_args["duration"] = duration

        if mode == "clone":
            ref_audio_path = args.get('ref_audio', '')
            ref_text = args.get('ref_text', '').strip()

            if not ref_audio_path or not os.path.exists(ref_audio_path):
                print(f"[OmniVoice] ERROR: Reference audio not found: {ref_audio_path}", file=sys.stderr, flush=True)
                return False

            gen_args["ref_audio"] = ref_audio_path
            if ref_text:
                gen_args["ref_text"] = ref_text
            print(f"[OmniVoice] Cloning voice from: {ref_audio_path}", flush=True)

        elif mode == "design":
            instruct = args.get('instruct', '').strip()
            if instruct:
                gen_args["instruct"] = instruct
            print(f"[OmniVoice] Voice design: {instruct[:60]}", flush=True)

        print("[OmniVoice] Generating...", flush=True)
        audio_tensors = model.generate(**gen_args)

        if not audio_tensors:
            print("[OmniVoice] ERROR: No audio output.", file=sys.stderr, flush=True)
            return False

        torchaudio.save(output_path, audio_tensors[0], 24000)
        duration_s = audio_tensors[0].shape[-1] / 24000
        print(f"[OmniVoice] Done! Saved to: {output_path}", flush=True)
        print(f"[OmniVoice] Duration: {duration_s:.2f}s", flush=True)
        return True

    except Exception as e:
        print(f"[OmniVoice] ERROR: {e}", file=sys.stderr, flush=True)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return False


def run_server(model_path):
    """Run in server mode — keep model in GPU, accept JSON commands via stdin."""
    model = load_model(model_path)
    print("[OmniVoice-Server] READY", flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        if line == "QUIT":
            print("[OmniVoice-Server] Shutting down...", flush=True)
            break
        if line == "PING":
            print("[OmniVoice-Server] PONG", flush=True)
            continue

        try:
            args = json.loads(line)
            success = run_inference_with_model(model, args)
            if success:
                print("[OmniVoice-Server] DONE", flush=True)
            else:
                print("[OmniVoice-Server] ERROR", flush=True)
        except Exception as e:
            print(f"[OmniVoice-Server] ERROR: {e}", file=sys.stderr, flush=True)
            print("[OmniVoice-Server] ERROR", flush=True)

    # Cleanup
    import torch
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    print("[OmniVoice-Server] STOPPED", flush=True)


def run_oneshot(args):
    """Run one-shot inference (load → generate → unload)."""
    model = load_model(args['model_path'])
    try:
        run_inference_with_model(model, args)
    finally:
        import torch
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


def main():
    if '--server' in sys.argv:
        parser = argparse.ArgumentParser()
        parser.add_argument('--server', action='store_true')
        parser.add_argument('--model-path', required=True)
        parsed = parser.parse_args()
        run_server(parsed.model_path)
        return

    if len(sys.argv) >= 3 and sys.argv[1] == '--config':
        config_path = sys.argv[2]
        if not os.path.exists(config_path):
            print(f"[OmniVoice] ERROR: Config file not found: {config_path}", file=sys.stderr)
            sys.exit(1)
        args = json.load(open(config_path, 'r', encoding='utf-8-sig'))
        run_oneshot(args)
        return

    print("[OmniVoice] Usage: python omnivoice_tts.py --config config.json")
    print("[OmniVoice]    or: python omnivoice_tts.py --server --model-path <path>")
    sys.exit(1)


if __name__ == "__main__":
    main()
