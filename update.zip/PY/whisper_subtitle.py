# -*- coding: utf-8 -*-
"""
whisper_subtitle.py
Phiên bản ASS-only:
- Dùng Faster-Whisper để tạo subtitle.
- Chỉ xuất file .ASS (Advanced SubStation Alpha).
- Không render / mux video, để ffmpeg + NVENC xử lý.
"""

import os, sys, time, json, shutil, subprocess, argparse
import traceback
import gc  # Garbage collector
from typing import List, Tuple

# --- 1. Cấu hình môi trường ---
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="ignore")
    except Exception:
        pass

def log(msg: str):
    try:
        print(msg, flush=True)
    except Exception:
        try:
            print(msg.encode("utf-8", "ignore").decode("utf-8", "ignore"), flush=True)
        except:
            pass

# Setup CUDA paths cho Windows
def setup_cuda_environment_windows():
    if os.name != "nt":
        return
    try:
        import site
        added = 0
        base_candidates = []
        for sp in site.getsitepackages():
            if "site-packages" in sp:
                base_candidates.append(os.path.join(sp, "nvidia"))

        cand_envs = [
            r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12\bin",
            r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11\bin",
        ]

        p = os.environ.get("PATH", "")
        for b in base_candidates:
            for sub in ["cudnn/bin", "cublas/bin", "cuda_runtime/bin", "cufft/bin", "curand/bin"]:
                d = os.path.join(b, sub)
                if os.path.isdir(d) and d not in p:
                    os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
                    p = os.environ["PATH"]
                    added += 1

        for d in cand_envs:
            if os.path.isdir(d) and d not in p:
                os.environ["PATH"] = d + os.pathsep + os.environ["PATH"]
                p = os.environ["PATH"]
                added += 1

        if added:
            log(f"[CUDA] Added {added} CUDA/cudnn paths.")
    except Exception as e:
        log(f"[CUDA] Setup warning: {e}")

setup_cuda_environment_windows()

# --- Import thư viện ---
import numpy as np

# Import Torch để clean VRAM
try:
    import torch
except ImportError:
    torch = None

try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None
    log("[ERR] Thư viện 'faster-whisper' chưa được cài đặt!")

# =========================
#  2. Utilities
# =========================
def hex_to_rgb(hex_str: str) -> Tuple[int, int, int]:
    s = hex_str.strip().lstrip("#")
    if len(s) == 3:
        s = "".join(ch * 2 for ch in s)
    if len(s) != 6:
        return (255, 255, 255)
    try:
        return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    except:
        return (255, 255, 255)

def seconds_to_ass_time(t: float) -> str:
    """Chuyển giây float -> định dạng ASS: H:MM:SS.cs"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    cs = int(round((t - int(t)) * 100))
    if cs == 100:
        cs = 0
        s += 1
        if s == 60:
            s = 0
            m += 1
            if m == 60:
                m = 0
                h += 1
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def seconds_to_srt_time(t: float) -> str:
    """Chuyển giây float -> định dạng SRT: HH:MM:SS,mmm"""
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms >= 1000:
        ms = 0
        s += 1
        if s == 60:
            s = 0
            m += 1
            if m == 60:
                m = 0
                h += 1
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def rgb_to_ass(r: int, g: int, b: int) -> str:
    """RGB -> &H00BBGGRR (ASS BGR + alpha=00)"""
    return f"&H00{b:02X}{g:02X}{r:02X}"

def rgba_box_color(r: int, g: int, b: int, alpha_percent: int) -> str:
    """
    Tạo màu box cho BackColour/OutlineColour dạng &HAABBGGRR
    ASS: AA = alpha (00 = opaque, FF = trong suốt)
    alpha_percent: 0-100 (0 = trong suốt, 100 = đặc)
    """
    alpha_percent = max(0, min(alpha_percent, 100))
    # 0% => trong suốt (FF), 100% => đặc (00)
    a = 255 - int(255 * (alpha_percent / 100.0))
    return f"&H{a:02X}{b:02X}{g:02X}{r:02X}"

# =========================
#  3. Quản lý Model (Tối ưu GPU)
# =========================
def check_model_health(model):
    try:
        dummy_audio = np.zeros(16000, dtype=np.float32)
        list(model.transcribe(dummy_audio, beam_size=1))
    except Exception as e:
        raise RuntimeError(f"Model health check failed: {e}")

def load_fw_robust(device_pref: str, model_id: str, compute_pref: str, device_index: int = 0):
    """Tải model có hỗ trợ device_index và fallback"""
    if WhisperModel is None:
        raise RuntimeError("faster-whisper not installed.")

    if device_pref in ("auto", "cuda"):
        candidates = []
        if compute_pref not in ("auto", ""):
            candidates.append(compute_pref)
        if "float16" not in candidates:
            candidates.append("float16")
        if "int8_float16" not in candidates:
            candidates.append("int8_float16")
        if "int8" not in candidates:
            candidates.append("int8")

        for ct in candidates:
            try:
                log(f"[FW] Thử GPU:{device_index} (Mode: {ct})...")
                model = WhisperModel(model_id, device="cuda", device_index=device_index, compute_type=ct)
                check_model_health(model)
                log(f"[FW] ✅ GPU:{device_index} ({ct}) OK.")
                return model
            except Exception as e:
                log(f"[FW] ⚠️ GPU ({ct}) lỗi: {e}")
                continue

        log("[FW] ❌ GPU thất bại. Chuyển sang CPU.")

    try:
        ct_cpu = "int8"
        log(f"[FW] Tải CPU (Mode: {ct_cpu})...")
        model = WhisperModel(model_id, device="cpu", compute_type=ct_cpu)
        check_model_health(model)
        log("[FW] ✅ CPU Model loaded.")
        return model
    except Exception as e:
        log(f"[FW] [CRITICAL] Lỗi tải model CPU: {e}")
        raise e

# =========================
#  4. Ghi file ASS
# =========================
def write_ass_file(subs: List[Tuple[float, float, str]], args) -> int:
    """
    Ghi file .ASS từ danh sách (start, end, text).
    Tôn trọng các tham số style từ app: font, size, màu, bo viền, margin, vị trí, bg box.
    """
    # Màu
    font_rgb = hex_to_rgb(args.font_color)
    outline_rgb = hex_to_rgb(args.outline_color)
    bg_rgb = hex_to_rgb(args.background_color)

    primary = rgb_to_ass(*font_rgb)
    secondary = primary  # không dùng, nhưng ASS cần field
    outline = rgb_to_ass(*outline_rgb)

    if args.bg_box and args.background_alpha_percent > 0:
        back = rgba_box_color(*bg_rgb, args.background_alpha_percent)
        border_style = 3  # Box như FFMPEG BorderStyle=3
        outline_for_style = back  # màu box
    else:
        back = "&HFF000000"  # full transparent black
        border_style = 1
        outline_for_style = outline

    playres_x = max(1, int(args.playres_x))
    playres_y = max(1, int(args.playres_y))
    margin_left = max(0, int(args.margin_left))
    margin_right = max(0, int(args.margin_right))

    pos = (args.position_tag or "bottom").lower()
    if "top" in pos:
        alignment = 8   # top-center
        margin_v = args.margin_top
    elif "center" in pos:
        alignment = 5   # middle-center
        margin_v = max(args.margin_top, args.margin_bottom)
    else:
        alignment = 2   # bottom-center
        margin_v = args.margin_bottom

    margin_v = max(0, int(margin_v))
    margin_l_str = f"{margin_left:04d}"
    margin_r_str = f"{margin_right:04d}"
    margin_v_str = f"{margin_v:04d}"

    use_custom_pos = int(getattr(args, "position_x", -1)) >= 0 and int(getattr(args, "position_y", -1)) >= 0
    if use_custom_pos:
        pos_x = max(0, min(playres_x, int(args.position_x)))
        pos_y = max(0, min(playres_y, int(args.position_y)))
        pos_tag = f"{{\\an8\\pos({pos_x},{pos_y})}}"
    else:
        pos_tag = ""

    header = f"""[Script Info]
; Script generated by whisper_subtitle.py (ASS-only mode)
ScriptType: v4.00+
PlayResX: {playres_x}
PlayResY: {playres_y}
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{args.font_name},{args.font_size},{primary},{secondary},{outline_for_style},{back},0,0,0,0,100,100,0,0,{border_style},{args.outline_width},1,{alignment},{margin_l_str},{margin_r_str},{margin_v_str},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    lines = [header]

    for start, end, text in subs:
        start_str = seconds_to_ass_time(start)
        end_str = seconds_to_ass_time(end)
        safe_text = (text or "").replace("\\n", " ").replace("\n", " ").replace("\r", " ")
        # Escape {} vì ASS dùng làm tag
        safe_text = safe_text.replace("{", "(").replace("}", ")")
        dialogue = f"Dialogue: 0,{start_str},{end_str},Default,,{margin_l_str},{margin_r_str},{margin_v_str},,{pos_tag}{safe_text}\n"
        lines.append(dialogue)

    os.makedirs(os.path.dirname(args.output_ass), exist_ok=True)
    with open(args.output_ass, "w", encoding="utf-8-sig") as f:
        f.writelines(lines)

    log(f"[ASS] Đã ghi file: {args.output_ass}")
    return 0


def write_srt_file(subs: List[Tuple[float, float, str]], output_path: str) -> None:
    """Ghi file .SRT từ danh sách (start, end, text)."""
    blocks = []
    for i, (start, end, text) in enumerate(subs, 1):
        start_str = seconds_to_srt_time(start)
        end_str = seconds_to_srt_time(end)
        safe_text = (text or "").replace("\r", "").strip()
        blocks.append(f"{i}\n{start_str} --> {end_str}\n{safe_text}")
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8-sig") as f:
        f.write("\n\n".join(blocks) + "\n")
    log(f"[SRT] Đã ghi file: {output_path}")


# =========================
#  5. Pipeline Chính
# =========================
def run_pipeline(args):
    log(f"[INFO] Start pipeline (ASS-only). GPU: {args.device_index}")

    # --- Bước 1: Load Model & Transcribe ---
    final_subs: List[Tuple[float, float, str]] = []

    try:
        model = load_fw_robust(args.device, args.model_id, args.compute_type, args.device_index)

        log("[ASR] Đang dịch giọng nói...")
        # Thử dùng BatchedInferencePipeline nếu có (faster-whisper >= 1.0)
        try:
            from faster_whisper import BatchedInferencePipeline
            batched = BatchedInferencePipeline(model=model)
            segments, _ = batched.transcribe(
                args.input_audio,
                language=args.language if args.language != "auto" else None,
                vad_filter=args.vad_filter,
                beam_size=args.beam_size,
                word_timestamps=args.word_timestamps,
                batch_size=args.batch_size,
            )
            log(f"[ASR] Dùng BatchedInferencePipeline (batch_size={args.batch_size})")
        except (ImportError, TypeError):
            # Fallback: phiên bản cũ không hỗ trợ batch
            segments, _ = model.transcribe(
                args.input_audio,
                language=args.language if args.language != "auto" else None,
                vad_filter=args.vad_filter,
                beam_size=args.beam_size,
                word_timestamps=args.word_timestamps,
            )
            log("[ASR] Dùng WhisperModel.transcribe() (no batch)")
        segments = list(segments)

        # Giải phóng model
        del model
        gc.collect()
        if torch and torch.cuda.is_available():
            torch.cuda.empty_cache()
        log(f"[ASR] Đã giải phóng Model khỏi GPU:{args.device_index}.")
    except Exception as e:
        log(f"[ERR] Lỗi Whisper: {e}")
        traceback.print_exc()
        return 1

    # --- Bước 2: Gom nhóm từ thành câu (words_per_line, overlap) ---
    def flush_buffer(buf, subs_list, overlap):
        if not buf:
            return
        start = buf[0]["start"]
        end = buf[-1]["end"]
        text = " ".join([w["word"].strip() for w in buf])

        if subs_list and overlap > 0:
            prev_end = subs_list[-1][1]
            start = max(subs_list[-1][0] + 0.1, min(start, prev_end - overlap))

        subs_list.append((start, end, text))

    for seg in segments:
        if not getattr(seg, "words", None):
            final_subs.append((seg.start, seg.end, seg.text.strip()))
            continue

        buffer = []
        for word in seg.words:
            buffer.append({"start": word.start, "end": word.end, "word": word.word})
            if len(buffer) >= args.words_per_line:
                flush_buffer(buffer, final_subs, args.overlap)
                buffer = []
        flush_buffer(buffer, final_subs, args.overlap)

    log(f"[ASR] Tổng dòng sub: {len(final_subs)}")

    if not final_subs:
        log("[WARN] Không có sub nào. Vẫn ghi file ASS trống.")
        open(args.output_ass, "w", encoding="utf-8-sig").write(
            "[Script Info]\n; Empty subtitle\nScriptType: v4.00+\n"
        )
        if getattr(args, "output_srt", None):
            open(args.output_srt, "w", encoding="utf-8-sig").write("")
        return 0

    # --- Bước 3: Ghi file ASS ---
    write_ass_file(final_subs, args)
    # --- Bước 4: Ghi file SRT (nếu có) ---
    if getattr(args, "output_srt", None):
        write_srt_file(final_subs, args.output_srt)
    return 0

# =========================
#  CLI Parser
# =========================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # IO
    parser.add_argument("--input_audio", required=True, help="Đường dẫn audio (m4a/mp3...)")
    parser.add_argument("--output_ass", required=True, help="Đường dẫn file .ass cần xuất")
    parser.add_argument("--output_srt", default="", help="Tuỳ chọn: đường dẫn file .srt (fast-whisper)")

    # Whisper Settings
    parser.add_argument("--model_id", default="medium")
    parser.add_argument("--model_dir", default="")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--device_index", type=int, default=0, help="ID của GPU (0, 1...)")
    parser.add_argument("--compute_type", default="auto")
    parser.add_argument("--language", default="vi")
    parser.add_argument("--vad_filter", action="store_true")
    parser.add_argument("--beam_size", type=int, default=2)
    parser.add_argument("--batch_size", type=int, default=16, help="Batch size cho transcribe (GPU: 16, CPU: 1)")
    parser.add_argument("--word_timestamps", action="store_true")

    # Subtitle Layout
    parser.add_argument("--words_per_line", type=int, default=8)
    parser.add_argument("--overlap", type=float, default=0.3)

    # Visual Style (để convert sang ASS Style)
    parser.add_argument("--font_name", default="Arial")
    parser.add_argument("--font_size", type=int, default=30)
    parser.add_argument("--font_color", default="#FFFFFF")
    parser.add_argument("--outline_width", type=int, default=2)
    parser.add_argument("--outline_color", default="#000000")
    parser.add_argument("--shadow", type=int, default=0)
    parser.add_argument("--position_tag", default="bottom")
    parser.add_argument("--playres_x", type=int, default=1920)
    parser.add_argument("--playres_y", type=int, default=1080)
    parser.add_argument("--margin_left", type=int, default=20)
    parser.add_argument("--margin_right", type=int, default=20)
    parser.add_argument("--margin_top", type=int, default=50)
    parser.add_argument("--margin_bottom", type=int, default=50)
    parser.add_argument("--position_x", type=int, default=-1)
    parser.add_argument("--position_y", type=int, default=-1)
    parser.add_argument("--max_width_percent", type=int, default=80)  # dùng cho preview, ASS không cần

    parser.add_argument("--bg_box", action="store_true")
    parser.add_argument("--background_color", default="#000000")
    parser.add_argument("--background_alpha", default="7F")
    parser.add_argument("--background_alpha_percent", type=int, default=0)

    # PyonFX Dummy (giữ để không lỗi param, nhưng ASS chưa dùng)
    parser.add_argument("--pyonfx_enabled", action="store_true")
    parser.add_argument("--pyonfx_effect", default="None")
    parser.add_argument("--pyonfx_easing", default="linear")
    parser.add_argument("--pyonfx_duration", type=float, default=1.0)
    parser.add_argument("--pyonfx_intensity", type=float, default=1.0)

    args = parser.parse_args()

    # Nếu model_dir trỏ tới thư mục có model.bin local → dùng luôn làm model_id
    if args.model_dir and os.path.isfile(os.path.join(args.model_dir, "model.bin")):
        log(f"[INFO] Dùng model local từ: {args.model_dir}")
        args.model_id = args.model_dir
    elif args.model_dir:
        os.environ["HF_HOME"] = args.model_dir
        os.environ["CT2_CACHES_DIR"] = args.model_dir

    sys.exit(run_pipeline(args))
