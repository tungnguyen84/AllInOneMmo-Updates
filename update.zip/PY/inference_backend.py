"""
Backend wrapper for Wav2Lip inference with progress tracking
"""
import os
import sys
import cv2
import numpy as np
import subprocess
import platform
import site
from PyQt6.QtCore import QThread, pyqtSignal, QObject
from PyQt6.QtWidgets import QApplication

# Setup CUDA paths for GPU acceleration
def setup_cuda_paths():
    """Setup CUDA library paths for GPU acceleration"""
    try:
        # Get site-packages directory
        site_packages = None
        for path in site.getsitepackages():
            if 'site-packages' in path:
                site_packages = path
                break
        
        if not site_packages:
            return
            
        nvidia_base = os.path.join(site_packages, 'nvidia')
        if not os.path.exists(nvidia_base):
            return
            
        # Add CUDA library paths
        cuda_paths = []
        for lib in ['cudnn', 'cublas', 'cuda_runtime', 'cufft', 'curand', 'cusolver', 'cusparse']:
            lib_path = os.path.join(nvidia_base, lib, 'bin')
            if os.path.exists(lib_path):
                cuda_paths.append(lib_path)
                
        # Add TensorRT path
        tensorrt_path = os.path.join(site_packages, 'tensorrt_libs')
        if os.path.exists(tensorrt_path):
            cuda_paths.append(tensorrt_path)
            
        # Add to PATH
        current_path = os.environ.get('PATH', '')
        new_paths = [p for p in cuda_paths if p not in current_path]
        if new_paths:
            os.environ['PATH'] = os.pathsep.join(new_paths) + os.pathsep + current_path
            print(f"✅ Added {len(new_paths)} CUDA paths for GPU acceleration")
            
    except Exception as e:
        print(f"Warning: Could not setup CUDA paths: {e}")

# Setup CUDA paths on import
setup_cuda_paths()

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

import audio
import onnxruntime
from insightface_func.face_detect_crop_single import Face_detect_crop


class InferenceArgs:
    """Arguments class matching original inference script"""
    def __init__(self):
        self.checkpoint_path = None
        self.face = None
        self.audio = None
        self.outfile = 'results/result_voice.mp4'
        self.static = False
        self.fps = 25.0
        self.pads = [0, 10, 0, 0]
        self.face_det_batch_size = 16  # Same as wav2lip-onnx2
        self.wav2lip_batch_size = 1   # Use stable config from wav2lip-onnx2
        self.resize_factor = 1
        self.crop = [0, -1, 0, -1]
        self.box = [-1, -1, -1, -1]
        self.rotate = False
        self.nosmooth = False
        self.preview = False
        self.img_size = 96
        self.enable_lipsync = True  # NEW: Enable/disable lip sync processing
        # Subtitle parameters
        self.subtitle_enabled = False
        self.subtitle_segments = None
        self.subtitle_config = None
        # Text overlay parameters
        self.text_overlays = []  # List of TextOverlayItem objects


class InferenceWorker(QThread):
    """Worker thread for running inference without blocking UI"""
    
    # Signals for communication with UI
    progress_updated = pyqtSignal(int)  # Progress percentage (0-100)
    status_updated = pyqtSignal(str)    # Status message
    frame_processed = pyqtSignal(np.ndarray)  # Current frame for preview
    error_occurred = pyqtSignal(str)    # Error message
    inference_completed = pyqtSignal(str)  # Final output file path
    
    def __init__(self, args: InferenceArgs):
        super().__init__()
        self.args = args
        self.is_cancelled = False

        
        # DEBUG: Print received subtitle config
        if hasattr(args, 'subtitle_config') and args.subtitle_config:
            print(f"🔧 BACKEND DEBUG: Received subtitle config:")
            print(f"   Enabled: {args.subtitle_config.get('enabled', 'NOT_SET')}")
            print(f"   Font size: {args.subtitle_config.get('font_size', 'NOT_SET')}")
            print(f"   Position: {args.subtitle_config.get('position', 'NOT_SET')}")
            print(f"   Margin bottom: {args.subtitle_config.get('margin_bottom', 'NOT_SET')}")
            print(f"   Max width ratio: {args.subtitle_config.get('max_width_ratio', 'NOT_SET')}")
        else:
            print(f"🔧 BACKEND DEBUG: No subtitle config received - args.subtitle_config = {getattr(args, 'subtitle_config', 'NOT_FOUND')}")
        
        self.whisper_generator = None
        # Initialize subtitle generator if subtitles are enabled
        if getattr(args, 'subtitle_enabled', False):
            try:
                from whisper_subtitle import WhisperSubtitleGenerator
                self.whisper_generator = WhisperSubtitleGenerator()
                print("✅ Whisper subtitle generator initialized")
            except Exception as e:
                print(f"❌ Failed to initialize subtitle generator: {e}")
                self.whisper_generator = None
        
        # Initialize text overlay processor if overlays exist
        if hasattr(args, 'text_overlays') and args.text_overlays:
            try:
                from ui.backend.text_overlay_processor import TextOverlayProcessor
                self._text_overlay_processor = TextOverlayProcessor()
                print("✅ Text overlay processor initialized")
            except Exception as e:
                print(f"❌ Failed to initialize text overlay processor: {e}")
                self._text_overlay_processor = None
        
    def cancel(self):
        """Cancel the inference process"""
        self.is_cancelled = True
        
    def run(self):
        """Main inference execution"""
        try:
            self.status_updated.emit("Khởi tạo...")
            self.progress_updated.emit(0)
            
            # Validate inputs
            if not self._validate_inputs():
                return
                
            # Load and prepare data
            full_frames, fps = self._load_video()
            if self.is_cancelled:
                return
                
            mel_chunks = self._prepare_audio(fps)
            if self.is_cancelled:
                return
                
            # Run inference
            self._run_inference(full_frames, mel_chunks, fps)
            
        except Exception as e:
            self.error_occurred.emit(f"Lỗi trong quá trình xử lý: {str(e)}")
            
    def _validate_inputs(self):
        """Validate input files and parameters"""
        if not os.path.isfile(self.args.face):
            self.error_occurred.emit('File ảnh/video không tồn tại')
            return False
            
        if not os.path.isfile(self.args.audio):
            self.error_occurred.emit('File audio không tồn tại')
            return False
            
        if not os.path.isfile(self.args.checkpoint_path):
            self.error_occurred.emit('File model không tồn tại')
            return False
            
        return True
        
    def _load_video(self):
        """Load video frames or static image"""
        self.status_updated.emit("Đang tải video...")
        self.progress_updated.emit(10)
        
        if self.args.face.split('.')[1].lower() in ['jpg', 'png', 'jpeg']:
            self.args.static = True
            full_frames = [cv2.imread(self.args.face)]
            fps = self.args.fps
        else:
            video_stream = cv2.VideoCapture(self.args.face)
            fps = video_stream.get(cv2.CAP_PROP_FPS)
            
            full_frames = []
            frame_count = int(video_stream.get(cv2.CAP_PROP_FRAME_COUNT))
            
            while True:
                if self.is_cancelled:
                    video_stream.release()
                    return None, None
                    
                still_reading, frame = video_stream.read()
                if not still_reading:
                    video_stream.release()
                    break
                    
                if self.args.resize_factor > 1:
                    frame = cv2.resize(frame, (frame.shape[1]//self.args.resize_factor, 
                                             frame.shape[0]//self.args.resize_factor))
                
                if self.args.rotate:
                    frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
                
                y1, y2, x1, x2 = self.args.crop
                if x2 == -1: x2 = frame.shape[1]
                if y2 == -1: y2 = frame.shape[0]
                frame = frame[y1:y2, x1:x2]
                
                full_frames.append(frame)
                
                # Update progress
                if frame_count > 0:
                    progress = 10 + int(20 * len(full_frames) / frame_count)
                    self.progress_updated.emit(min(progress, 30))
        
        self.status_updated.emit(f"Đã tải {len(full_frames)} frames")
        return full_frames, fps
        
    def _prepare_audio(self, fps=25.0):
        """Prepare audio and create mel spectrograms"""
        self.status_updated.emit("Đang xử lý audio...")
        self.progress_updated.emit(35)
        
        # Convert to wav if needed
        audio_path = self.args.audio
        if not self.args.audio.endswith('.wav'):
            self.status_updated.emit("Đang chuyển đổi audio...")
            os.makedirs('Temp', exist_ok=True)
            temp_wav = 'Temp/temp.wav'
            command = f'ffmpeg -y -i "{self.args.audio}" -strict -2 "{temp_wav}"'
            subprocess.call(command, shell=True)
            audio_path = temp_wav
            
        # Load and process audio
        wav = audio.load_wav(audio_path, 16000)
        mel = audio.melspectrogram(wav)
        
        if np.isnan(mel.reshape(-1)).sum() > 0:
            raise ValueError('Mel spectrogram chứa NaN! Có thể do file audio lỗi.')
            
        # Create mel chunks - USE ACTUAL FPS
        mel_chunks = []
        mel_idx_multiplier = 80.0 / fps  # Use actual video FPS
        mel_step_size = 16
        
        i = 0
        while True:
            start_idx = int(i * mel_idx_multiplier)
            if start_idx + mel_step_size > len(mel[0]):
                mel_chunks.append(mel[:, len(mel[0]) - mel_step_size:])
                break
            mel_chunks.append(mel[:, start_idx : start_idx + mel_step_size])
            i += 1
            
        self.progress_updated.emit(40)
        return mel_chunks
        
    def _run_inference(self, full_frames, mel_chunks, fps):
        """Run the main inference loop"""
        self.status_updated.emit("Bắt đầu sinh video...")
        self.progress_updated.emit(45)
        
        # Check for GPU support properly - test actual availability
        device = 'cpu'
        working_providers = []
        
        # Test each provider to see if it actually works
        test_providers = [
            ('TensorrtExecutionProvider', 'tensorrt'),
            ('CUDAExecutionProvider', 'cuda'), 
            ('DmlExecutionProvider', 'directml')
        ]
        
        for provider_name, device_type in test_providers:
            if provider_name in onnxruntime.get_available_providers():
                try:
                    # Try to create a simple session to test if provider works
                    test_options = onnxruntime.SessionOptions()
                    test_session = onnxruntime.InferenceSession(
                        self.args.checkpoint_path,
                        sess_options=test_options,
                        providers=[provider_name, "CPUExecutionProvider"]
                    )
                    # If we get here, the provider works
                    device = device_type
                    self.status_updated.emit(f"Sử dụng GPU ({device_type.upper()})")
                    del test_session  # Clean up
                    break
                except Exception as e:
                    # Provider doesn't work, try next one
                    continue
        
        if device == 'cpu':
            self.status_updated.emit("Sử dụng CPU (GPU không khả dụng)")
            
        # Check if lip sync is enabled
        if not self.args.enable_lipsync:
            # Subtitle-only mode: just add subtitles to original frames
            self._process_subtitle_only_mode(full_frames, fps)
            return
            
        # Generate subtitles if needed for lip sync mode
        if self.args.subtitle_enabled and not self.args.subtitle_segments:
            self.status_updated.emit("Tạo phụ đề từ audio...")
            self.progress_updated.emit(35)
            
            try:
                print(f"🔧 DEBUG: Creating subtitle generator...")
                from whisper_subtitle import WhisperSubtitleGenerator
                generator = WhisperSubtitleGenerator()
                print(f"🔧 DEBUG: Generator created successfully")
                
                # Apply config
                config = self.args.subtitle_config or {}
                print(f"🔧 DEBUG: Subtitle config: {config}")
                generator.config.language = config.get('language', 'vi')
                generator.config.max_words_per_subtitle = config.get('words_per_subtitle', 8)
                generator.config.overlap_duration = config.get('overlap_duration', 0.3)
                
                # Generate subtitles from audio
                print(f"🔧 DEBUG: Generating subtitles from audio: {self.args.audio}")
                segments = generator.generate_subtitles(self.args.audio)
                self.args.subtitle_segments = segments
                
                print(f"🔧 DEBUG: Generated {len(segments)} subtitle segments")
                self.status_updated.emit(f"Tạo được {len(segments)} phân đoạn phụ đề")
                
            except Exception as e:
                print(f"❌ DEBUG: Error generating subtitles: {str(e)}")
                self.status_updated.emit(f"Lỗi tạo phụ đề: {str(e)}")
                # Continue with lip sync only
            
        model = self._load_model(device)
        
        # Prepare output
        # For static images, replicate the single frame to match mel_chunks length
        if self.args.static and len(full_frames) == 1:
            # Replicate the single frame to match audio length
            static_frame = full_frames[0].copy()
            full_frames = [static_frame.copy() for _ in range(len(mel_chunks))]
            print(f"🔧 DEBUG: Static image - Replicated frame {len(mel_chunks)} times")
        else:
            full_frames = full_frames[:len(mel_chunks)]
            
        frame_h, frame_w = full_frames[0].shape[:-1]
        
        os.makedirs('Temp', exist_ok=True)
        temp_video = 'Temp/result.avi'
        out = cv2.VideoWriter(temp_video, cv2.VideoWriter_fourcc(*'DIVX'), fps, (frame_w, frame_h))
        
        # Data generator - use batch_size = 1 for stability like wav2lip-onnx2
        batch_size = 1  # Force batch_size = 1 for stable frame-audio sync
        gen = self._datagen(full_frames.copy(), mel_chunks)
        total_batches = int(np.ceil(len(mel_chunks) / batch_size))
        
        batch_idx = 0
        frame_idx = 0
        for img_batch, mel_batch, frames, coords in gen:
            if self.is_cancelled:
                out.release()
                return
                
            # Run inference
            img_batch = img_batch.transpose((0, 3, 1, 2)).astype(np.float32)
            mel_batch = mel_batch.transpose((0, 3, 1, 2)).astype(np.float32)
            
            pred = model.run(None, {
                'mel_spectrogram': mel_batch, 
                'video_frames': img_batch
            })[0][0]
            
            pred = pred.transpose(1, 2, 0) * 255
            pred = pred.astype(np.uint8)
            pred = pred.reshape((1, 96, 96, 3))
            
            # Process frames
            for p, f, c in zip(pred, frames, coords):
                y1, y2, x1, x2 = c
                p = cv2.resize(p, (x2 - x1, y2 - y1))
                f[y1:y2, x1:x2] = p
                
                # Add subtitle overlay if enabled
                frame_with_subtitle = f.copy()
                if self.args.subtitle_enabled and self.args.subtitle_segments:
                    frame_with_subtitle = self._add_subtitle_to_frame(
                        frame_with_subtitle, 
                        frame_idx / fps
                    )
                
                out.write(frame_with_subtitle)
                
                # Emit frame for preview
                if self.args.preview:
                    self.frame_processed.emit(frame_with_subtitle.copy())
                    
                frame_idx += 1
                    
            # Update progress
            batch_idx += 1
            progress = 45 + int(45 * batch_idx / total_batches)
            self.progress_updated.emit(min(progress, 90))
            self.status_updated.emit(f"Đang xử lý batch {batch_idx}/{total_batches}")
            
        out.release()
        
        if self.is_cancelled:
            return
            
        # Combine with audio
        self.status_updated.emit("Đang kết hợp audio...")
        self.progress_updated.emit(95)
        
        os.makedirs(os.path.dirname(self.args.outfile), exist_ok=True)
        command = f'ffmpeg -y -i "{self.args.audio}" -i "{temp_video}" -strict -2 -q:v 1 "{self.args.outfile}"'
        subprocess.call(command, shell=platform.system() != 'Windows')
        
        # Cleanup
        if os.path.exists(temp_video):
            os.remove(temp_video)
            
        self.progress_updated.emit(100)
        self.status_updated.emit("Hoàn thành!")
        self.inference_completed.emit(self.args.outfile)
        
    def _process_subtitle_only_mode(self, full_frames, fps):
        """Process video in subtitle-only mode (no lip sync)"""
        self.status_updated.emit("Chế độ chỉ phụ đề - Không nhép miệng...")
        self.progress_updated.emit(50)
        
        # Generate subtitles if not provided
        if self.args.subtitle_enabled and not self.args.subtitle_segments:
            self.status_updated.emit("Tạo phụ đề từ audio...")
            self.progress_updated.emit(30)
            
            try:
                from whisper_subtitle import WhisperSubtitleGenerator
                generator = WhisperSubtitleGenerator()
                
                # Apply config
                config = self.args.subtitle_config or {}
                generator.config.language = config.get('language', 'vi')
                generator.config.max_words_per_subtitle = config.get('words_per_subtitle', 8)
                generator.config.overlap_duration = config.get('overlap_duration', 0.3)
                
                # Generate subtitles from audio
                segments = generator.generate_subtitles(self.args.audio)
                self.args.subtitle_segments = segments
                
                self.status_updated.emit(f"Tạo được {len(segments)} phân đoạn phụ đề")
                
            except Exception as e:
                self.status_updated.emit(f"Lỗi tạo phụ đề: {str(e)}")
                # Continue without subtitles
                
        frame_h, frame_w = full_frames[0].shape[:-1]
        
        os.makedirs('Temp', exist_ok=True)
        temp_video = 'Temp/result.avi'
        out = cv2.VideoWriter(temp_video, cv2.VideoWriter_fourcc(*'DIVX'), fps, (frame_w, frame_h))
        
        # For static images, calculate total frames based on audio duration
        if self.args.static and self.args.subtitle_segments:
            # Calculate video duration from subtitle segments or audio
            import librosa
            try:
                audio_duration = librosa.get_duration(filename=self.args.audio)
                total_frames = int(audio_duration * fps)
                self.status_updated.emit(f"Tạo video {audio_duration:.1f}s từ ảnh tĩnh")
                print(f"🔧 DEBUG: Static image mode - Audio duration: {audio_duration:.1f}s, Total frames: {total_frames}")
            except Exception as e:
                # Fallback: use last subtitle end time
                if self.args.subtitle_segments:
                    max_end_time = max(seg['end'] for seg in self.args.subtitle_segments)
                    total_frames = int(max_end_time * fps)
                    self.status_updated.emit(f"Tạo video {max_end_time:.1f}s từ phụ đề")
                    print(f"🔧 DEBUG: Using subtitle duration: {max_end_time:.1f}s, Total frames: {total_frames}")
                else:
                    total_frames = len(full_frames)  # Fallback to single frame
        else:
            total_frames = len(full_frames)
        
        # Process each frame without lip sync
        for frame_idx in range(total_frames):
            if self.is_cancelled:
                out.release()
                return
                
            # For static images, use the same frame; for videos, use corresponding frame
            if self.args.static:
                frame = full_frames[0].copy()  # Always use the static image
            else:
                frame = full_frames[frame_idx].copy()
            
            frame_with_subtitle = frame.copy()
            
            # Add subtitle overlay if enabled
            if self.args.subtitle_enabled and self.args.subtitle_segments:
                current_time = frame_idx / fps
                frame_with_subtitle = self._add_subtitle_to_frame(
                    frame_with_subtitle, 
                    current_time
                )
            
            out.write(frame_with_subtitle)
            
            # Emit frame for preview
            if self.args.preview:
                self.frame_processed.emit(frame_with_subtitle.copy())
                
            # Update progress
            progress = 50 + int(40 * frame_idx / total_frames)
            self.progress_updated.emit(min(progress, 90))
            
            if frame_idx % 10 == 0:  # Update status every 10 frames
                self.status_updated.emit(f"Xử lý frame {frame_idx + 1}/{total_frames}")
        
        out.release()
        
        if self.is_cancelled:
            return
            
        # Combine with audio
        self.status_updated.emit("Đang kết hợp audio...")
        self.progress_updated.emit(95)
        
        os.makedirs(os.path.dirname(self.args.outfile), exist_ok=True)
        command = f'ffmpeg -y -i "{self.args.audio}" -i "{temp_video}" -strict -2 -q:v 1 "{self.args.outfile}"'
        subprocess.call(command, shell=platform.system() != 'Windows')
        
        # Cleanup
        if os.path.exists(temp_video):
            os.remove(temp_video)
            
        self.progress_updated.emit(100)
        self.status_updated.emit("Hoàn thành chế độ chỉ phụ đề!")
        self.inference_completed.emit(self.args.outfile)
        
    def _load_model(self, device):
        """Load ONNX model with working provider"""
        session_options = onnxruntime.SessionOptions()
        session_options.graph_optimization_level = onnxruntime.GraphOptimizationLevel.ORT_ENABLE_ALL
        session_options.enable_mem_pattern = True
        session_options.enable_cpu_mem_arena = True
        
        # Advanced provider selection with TensorRT optimization
        if device == 'tensorrt':
            providers = [
                ("TensorrtExecutionProvider", {
                    'device_id': 0,
                    'trt_max_workspace_size': 2147483648,  # 2GB
                    'trt_fp16_enable': True,
                    'trt_engine_cache_enable': True,
                    'trt_engine_cache_path': './cache'
                }),
                "CUDAExecutionProvider", 
                "CPUExecutionProvider"
            ]
        elif device == 'cuda':
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] 
        elif device == 'directml':
            providers = ["DmlExecutionProvider", "CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]
            
        session = onnxruntime.InferenceSession(
            self.args.checkpoint_path, 
            sess_options=session_options, 
            providers=providers
        )
        
        # Log which provider is actually being used
        used_providers = session.get_providers()
        self.status_updated.emit(f"✅ Loaded: {used_providers[0]}")
        
        return session
        
    def _get_smoothened_boxes(self, boxes, T):
        """Smooth face detection boxes"""
        for i in range(len(boxes)):
            if i + T > len(boxes):
                window = boxes[len(boxes) - T:]
            else:
                window = boxes[i : i + T]
            boxes[i] = np.mean(window, axis=0)
        return boxes
        
    def _face_detect(self, images):
        """Detect faces in images"""
        detector = Face_detect_crop(name='antelope', root='./insightface_func/models')
        detector.prepare(ctx_id=0, det_thresh=0.3, det_size=(320, 320), mode='none')
        
        predictions = []
        for i, img in enumerate(images):
            bbox = detector.getBox(img)
            predictions.append(bbox)
            
        results = []
        pady1, pady2, padx1, padx2 = self.args.pads
        
        for rect, image in zip(predictions, images):
            if rect is None:
                os.makedirs('Temp', exist_ok=True)
                cv2.imwrite('Temp/faulty_frame.jpg', image)
                raise ValueError('Không phát hiện được khuôn mặt! Đảm bảo video chứa khuôn mặt rõ ràng.')
                
            y1 = max(0, rect[1] - pady1)
            y2 = min(image.shape[0], rect[3] + pady2)
            x1 = max(0, rect[0] - padx1)
            x2 = min(image.shape[1], rect[2] + padx2)
            
            results.append([x1, y1, x2, y2])
            
        boxes = np.array(results)
        if not self.args.nosmooth:
            boxes = self._get_smoothened_boxes(boxes, T=5)
            
        results = [[image[y1: y2, x1:x2], (y1, y2, x1, x2)] 
                  for image, (x1, y1, x2, y2) in zip(images, boxes)]
        
        del detector
        return results
        
    def _datagen(self, frames, mels):
        """Generate batches for inference"""
        img_batch, mel_batch, frame_batch, coords_batch = [], [], [], []
        
        if self.args.box[0] == -1:
            if not self.args.static:
                face_det_results = self._face_detect(frames)
            else:
                face_det_results = self._face_detect([frames[0]])
        else:
            y1, y2, x1, x2 = self.args.box
            face_det_results = [[f[y1: y2, x1:x2], (y1, y2, x1, x2)] for f in frames]
            
        for i, m in enumerate(mels):
            idx = 0 if self.args.static else i % len(frames)
            frame_to_save = frames[idx].copy()
            face, coords = face_det_results[idx].copy()
            
            face = cv2.resize(face, (self.args.img_size, self.args.img_size))
            
            img_batch.append(face)
            mel_batch.append(m)
            frame_batch.append(frame_to_save)
            coords_batch.append(coords)
            
            if len(img_batch) >= 1:  # Process one frame at a time for stability
                img_batch, mel_batch = np.asarray(img_batch), np.asarray(mel_batch)
                
                img_masked = img_batch.copy()
                img_masked[:, self.args.img_size//2:] = 0
                
                img_batch = np.concatenate((img_masked, img_batch), axis=3) / 255.
                mel_batch = np.reshape(mel_batch, [len(mel_batch), mel_batch.shape[1], mel_batch.shape[2], 1])
                
                yield img_batch, mel_batch, frame_batch, coords_batch
                img_batch, mel_batch, frame_batch, coords_batch = [], [], [], []
                
        if len(img_batch) > 0:
            img_batch, mel_batch = np.asarray(img_batch), np.asarray(mel_batch)
            
            img_masked = img_batch.copy()
            img_masked[:, self.args.img_size//2:] = 0
            
            img_batch = np.concatenate((img_masked, img_batch), axis=3) / 255.
            mel_batch = np.reshape(mel_batch, [len(mel_batch), mel_batch.shape[1], mel_batch.shape[2], 1])
            
            yield img_batch, mel_batch, frame_batch, coords_batch
    
    def _add_subtitle_to_frame(self, frame, current_time):
        """Add subtitle overlay with PyonFX effects to frame"""
        try:
            processed_frame = frame
            
            # First apply text overlays
            if hasattr(self.args, 'text_overlays') and self.args.text_overlays:
                processed_frame = self._add_text_overlays_to_frame(processed_frame, current_time)
            
            # Then apply subtitles (they appear on top)
            # Check if subtitle is enabled and config available
            if not self.args.subtitle_config or not getattr(self.args, 'subtitle_enabled', False):
                return processed_frame
                
            # If no pre-generated segments, subtitle generation should happen in main inference
            if not self.args.subtitle_segments:
                return processed_frame
                
            # Find subtitle for current time
            current_subtitle = None
            current_segment = None
            for segment in self.args.subtitle_segments:
                if segment.start <= current_time <= segment.end:
                    current_subtitle = segment.text
                    current_segment = segment
                    break
                    
            if not current_subtitle or not current_segment:
                return processed_frame
                
            # Check if PyonFX effects are enabled
            subtitle_config = self.args.subtitle_config
            pyonfx_enabled = subtitle_config.get('pyonfx_enabled', False)
            
            print(f"🔧 BACKEND DEBUG: Subtitle at {current_time:.2f}s - Text: '{current_subtitle[:30]}...', PyonFX: {pyonfx_enabled}")
            print(f"   Config margin_bottom: {subtitle_config.get('margin_bottom', 'NOT_SET')}")
            print(f"   Config font_size: {subtitle_config.get('font_size', 'NOT_SET')}")
            
            if pyonfx_enabled:
                # Use PyonFX animation effects
                print(f"🎬 BACKEND DEBUG: Using PyonFX effects!")
                return self._render_pyonfx_subtitle(processed_frame, current_subtitle, current_segment, current_time, subtitle_config)
            else:
                # Use basic subtitle rendering
                print(f"📝 BACKEND DEBUG: Using basic subtitle rendering")
                return self._render_basic_subtitle(processed_frame, current_subtitle, subtitle_config)
                
        except Exception as e:
            print(f"❌ BACKEND ERROR: Error adding subtitle/overlays: {e}")
            import traceback
            traceback.print_exc()
            return frame
    
    def _render_pyonfx_subtitle(self, frame, subtitle_text, segment, current_time, config):
        """Render subtitle with PyonFX animation effects"""
        try:
            from ui.effects.pyonfx_effects import PyonFXEffects, EffectType, EasingType
            from ui.effects.animation_engine import AnimationEngine
            
            # Get PyonFX settings from config - FIX KEY NAMES
            effect_type = EffectType(config.get('pyonfx_effect_type', 'fade_in'))
            easing_type = EasingType(config.get('pyonfx_easing', 'linear'))
            duration = config.get('pyonfx_duration', 1.0)
            print(f"🔧 BACKEND: Using effect_type={effect_type.value} from config key 'pyonfx_effect_type'")
            
            # Calculate animation progress based on timing
            segment_duration = segment.end - segment.start
            time_in_segment = current_time - segment.start
            
            # Regular animation effect - Sửa progress calculation
            effect_duration = config.get('pyonfx_duration', 1.0)
            
            # Tính progress trong phạm vi effect duration
            if time_in_segment <= effect_duration:
                # Animation đang diễn ra
                progress = time_in_segment / effect_duration
                print(f"🎬 Animation progress: {progress:.2f} (time: {time_in_segment:.2f}s / duration: {effect_duration:.2f}s)")
            elif effect_type.value.endswith('_out') and (segment_duration - time_in_segment) <= effect_duration:
                # Fade out effect ở cuối segment
                progress = (segment_duration - time_in_segment) / effect_duration
                print(f"🎬 Fade out progress: {progress:.2f}")
            else:
                # Hiển thị static (animation đã hoàn thành)
                progress = 1.0
                print(f"🎬 Static display (animation completed)")
            
            progress = max(0.0, min(1.0, progress))  # Clamp to [0, 1]
            
            print(f"🎯 Final progress: {progress:.2f} for effect {effect_type.value}")
            
            # Generate frame with effect
            frame_with_subtitle = self._apply_single_effect(
                frame, subtitle_text, effect_type.value, progress, config
            )
            
            return frame_with_subtitle
            
        except Exception as e:
            print(f"Error rendering PyonFX subtitle: {e}")
            # Fallback to basic rendering
            return self._render_basic_subtitle(frame, subtitle_text, config)
    
    def _apply_single_effect(self, frame, subtitle_text, effect_type, progress, config):
        """Apply single PyonFX effect to subtitle"""
        try:
            from ui.effects.pyonfx_effects import PyonFXEffects, EffectType, EffectConfig, EasingType
            from PIL import Image, ImageDraw, ImageFont
            import cv2
            import numpy as np
            
            print(f"✨ DEBUG: Applying effect {effect_type} with progress {progress:.2f}")
            
            # Convert frame to PIL
            frame_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            
            # Create subtitle overlay first
            overlay = Image.new('RGBA', frame_pil.size, (0, 0, 0, 0))
            draw = ImageDraw.Draw(overlay)
            
            # Get frame dimensions
            frame_width, frame_height = frame_pil.size
            
            # Load font - use font size as-is, no auto scaling
            font_size = config.get('font_size', 48)
            try:
                font = ImageFont.truetype("arial.ttf", font_size)
            except:
                font = ImageFont.load_default()
            
            # Handle text wrapping based on max_width_ratio
            max_width_ratio = config.get('max_width_ratio', 0.8)
            # Use actual frame width for proper max width application
            frame_max_text_width = int(frame_width * max_width_ratio)  # Based on actual frame size
            print(f"🎯 Backend inference using frame-based max text width: {frame_max_text_width}px for frame {frame_width}x{frame_height} (ratio={max_width_ratio})")
            
            def get_text_dimensions(text, font):
                bbox = draw.textbbox((0, 0), text, font=font)
                return bbox[2] - bbox[0], bbox[3] - bbox[1]
            
            # Check if text needs wrapping
            text_width, text_height = get_text_dimensions(subtitle_text, font)
            
            if text_width > frame_max_text_width:
                # Text is too wide, need to wrap
                lines = []
                words = subtitle_text.split()
                
                if len(words) == 1:
                    # Single long word - can't wrap, use as is but limit to max width
                    lines = [subtitle_text]
                else:
                    # Multiple words - wrap intelligently
                    current_line = ""
                    for word in words:
                        test_line = current_line + (" " if current_line else "") + word
                        test_width, _ = get_text_dimensions(test_line, font)
                        
                        if test_width <= frame_max_text_width:
                            current_line = test_line
                        else:
                            if current_line:
                                lines.append(current_line)
                                current_line = word
                            else:
                                # Single word is too long
                                lines.append(word)
                                current_line = ""
                    
                    if current_line:
                        lines.append(current_line)
                
                # Calculate total height for multi-line text with proper line spacing
                line_height = text_height
                line_spacing = int(line_height * 0.2)  # 20% of line height for spacing
                effective_line_height = line_height + line_spacing
                total_text_height = len(lines) * line_height + (len(lines) - 1) * line_spacing
                max_line_width = max(get_text_dimensions(line, font)[0] for line in lines)
                
            else:
                # Text fits in one line
                lines = [subtitle_text]
                total_text_height = text_height
                max_line_width = text_width
            
            # Calculate position
            position = config.get('position', 'Dưới cùng')
            margin_bottom = config.get('margin_bottom', 50)
            margin_top = config.get('margin_top', 50)
            
            # Scale margins proportionally to maintain consistent relative position
            # Base on 1080p as reference
            reference_height = 1080
            margin_scale = frame_height / reference_height
            
            scaled_margin_bottom = int(margin_bottom * margin_scale)
            scaled_margin_top = int(margin_top * margin_scale)
            
            # Calculate starting Y position based on total text height
            if position == 'Dưới cùng':
                start_y = frame_height - total_text_height - scaled_margin_bottom
                print(f"📍 Backend Bottom: frame_height={frame_height}, margin={margin_bottom}->{scaled_margin_bottom} (scale={margin_scale:.3f}), start_y={start_y}")
            elif position == 'Trên cùng':
                start_y = scaled_margin_top
                print(f"📍 Backend Top: margin={margin_top}->{scaled_margin_top} (scale={margin_scale:.3f}), start_y={start_y}")
            else:  # center
                start_y = (frame_height - total_text_height) // 2
                print(f"📍 Backend Center: start_y={start_y}")
            
            # Get colors
            font_color = tuple(config.get('font_color', [255, 255, 255]))
            outline_color = tuple(config.get('outline_color', [0, 0, 0]))
            outline_width = config.get('outline_width', 2)
            
            # Draw background if enabled
            if config.get('background_enabled', True):
                bg_color = config.get('background_color', (0, 0, 0, 128))
                if len(bg_color) >= 4 and bg_color[3] > 0:
                    padding = 8
                    bg_x1 = (frame_width - max_line_width) // 2 - padding
                    bg_y1 = start_y - padding
                    bg_x2 = (frame_width + max_line_width) // 2 + padding
                    bg_y2 = start_y + total_text_height + padding
                    
                    draw.rectangle([bg_x1, bg_y1, bg_x2, bg_y2], fill=bg_color)
                    print(f"🎨 Backend background: {bg_color}")
            
            print(f"🎨 DEBUG: Drawing {len(lines)} lines of text starting at y={start_y}")
            
            # Draw each line of text with proper spacing
            for i, line in enumerate(lines):
                line_width, line_height = get_text_dimensions(line, font)
                
                # Center each line horizontally
                x = (frame_width - line_width) // 2
                y = start_y + (i * effective_line_height)  # Use effective line height with spacing
                
                # Draw text with outline
                for dx in range(-outline_width, outline_width + 1):
                    for dy in range(-outline_width, outline_width + 1):
                        if dx != 0 or dy != 0:
                            draw.text((x + dx, y + dy), line, font=font, fill=outline_color)
                
                # Draw main text
                draw.text((x, y), line, font=font, fill=font_color)
            
            # Create effect config
            try:
                effect_enum = EffectType(effect_type)
            except:
                effect_enum = EffectType.FADE_IN
                
            try:
                easing_enum = EasingType(config.get('pyonfx_easing', 'ease_in'))
            except:
                easing_enum = EasingType.EASE_IN
            
            effect_config = EffectConfig(
                effect_type=effect_enum,
                duration=config.get('pyonfx_duration', 1.0),
                easing=easing_enum,
                intensity=config.get('pyonfx_intensity', 1.0),
                secondary_color=config.get('pyonfx_secondary_color', (255, 255, 0))
            )
            
            print(f"🎯 DEBUG: Applying {effect_enum} with progress {progress:.2f}")
            
            # Check overlay alpha before effect
            overlay_data_before = np.array(overlay)
            alpha_before = overlay_data_before[:,:,3].max() if overlay_data_before.shape[2] > 3 else 255
            print(f"📊 DEBUG: Overlay alpha before effect: {alpha_before}")
            
            # Apply PyonFX effect to overlay - complete subtitle with background, outline, text
            overlay = PyonFXEffects.apply_effect(overlay, progress, effect_config)
            
            # Check overlay alpha after effect
            overlay_data_after = np.array(overlay)
            alpha_after = overlay_data_after[:,:,3].max() if overlay_data_after.shape[2] > 3 else 255
            print(f"📊 DEBUG: Overlay alpha after effect: {alpha_after}")
            
            # Composite overlay onto frame
            if frame_pil.mode != 'RGBA':
                frame_pil = frame_pil.convert('RGBA')
            
            result_frame = Image.alpha_composite(frame_pil, overlay)
            result_frame = result_frame.convert('RGB')
            
            print(f"✅ DEBUG: Effect applied successfully")
            
            # Convert back to OpenCV format
            return cv2.cvtColor(np.array(result_frame), cv2.COLOR_RGB2BGR)
            
        except Exception as e:
            print(f"❌ Error applying single effect {effect_type}: {e}")
            import traceback
            traceback.print_exc()
            return frame
    
    def _render_static_text(self, frame_pil, params):
        """Render static text on frame with same logic as video subtitle rendering"""
        try:
            from PIL import ImageDraw, ImageFont
            
            draw = ImageDraw.Draw(frame_pil)
            
            # Get frame dimensions
            frame_width, frame_height = frame_pil.size
            
            # Scale font size proportionally to maintain consistent relative appearance
            # Base on 1080p as reference resolution - SAME AS VIDEO RENDERING
            reference_height = 1080
            font_scale = frame_height / reference_height
            scaled_font_size = int(params['font_size'] * font_scale)
            print(f"🎯 Static text font: {params['font_size']}px -> {scaled_font_size}px (scale={font_scale:.3f}) for frame {frame_width}x{frame_height}")
            
            try:
                font = ImageFont.truetype("arial.ttf", scaled_font_size)
            except:
                font = ImageFont.load_default()
            
            # Text wrapping logic - BASED ON ACTUAL FRAME SIZE
            text = params['text']
            max_width_ratio = params.get('max_width_ratio', 0.8)
            # Use actual frame width for proper max width application
            frame_max_width = int(frame_width * max_width_ratio)  # Based on actual frame size
            
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            
            if text_width > frame_max_width:
                # Split text into multiple lines - SAME LOGIC AS VIDEO
                words = text.split()
                lines = []
                current_line = ""
                
                for word in words:
                    test_line = current_line + (" " if current_line else "") + word
                    test_bbox = draw.textbbox((0, 0), test_line, font=font)
                    test_width = test_bbox[2] - test_bbox[0]
                    
                    if test_width <= frame_max_width:
                        current_line = test_line
                    else:
                        if current_line:
                            lines.append(current_line)
                            current_line = word
                        else:
                            lines.append(word)
                
                if current_line:
                    lines.append(current_line)
            else:
                lines = [text]
            
            # Calculate line height and total height - SAME AS VIDEO
            sample_bbox = draw.textbbox((0, 0), "Mg", font=font)
            line_height = sample_bbox[3] - sample_bbox[1]
            line_spacing = int(line_height * 0.2)
            total_height = len(lines) * line_height + (len(lines) - 1) * line_spacing
            
            # Scale margins proportionally - SAME AS VIDEO
            margin_scale = frame_height / reference_height
            scaled_margin_bottom = int(params['margin_bottom'] * margin_scale)
            scaled_margin_top = int(params['margin_top'] * margin_scale)
            
            # Calculate starting Y position
            if params['position'] == 'Trên cùng':
                start_y = scaled_margin_top
            elif params['position'] == 'Giữa':
                start_y = (frame_height - total_height) // 2
            else:  # Bottom
                start_y = frame_height - total_height - scaled_margin_bottom
            
            # Draw outline and text for each line - SAME AS VIDEO
            outline_width = params['outline_width']
            outline_color = tuple(params['outline_color'][:3])
            font_color = tuple(params['font_color'][:3])
            
            for i, line in enumerate(lines):
                line_bbox = draw.textbbox((0, 0), line, font=font)
                line_width = line_bbox[2] - line_bbox[0]
                x = (frame_width - line_width) // 2  # Center each line
                y = start_y + i * (line_height + line_spacing)
                
                # Draw outline
                if outline_width > 0:
                    for dx in range(-outline_width, outline_width + 1):
                        for dy in range(-outline_width, outline_width + 1):
                            if dx != 0 or dy != 0:
                                draw.text((x + dx, y + dy), line, font=font, fill=outline_color)
                
                # Draw main text
                draw.text((x, y), line, font=font, fill=font_color)
            
            return frame_pil
            
        except Exception as e:
            print(f"Error rendering static text: {e}")
            return frame_pil
    
    def _render_basic_subtitle(self, frame, subtitle_text, config):
        """Fallback basic subtitle rendering"""
        try:
            # Use WhisperSubtitleGenerator for basic rendering
            if not self.whisper_generator:
                from whisper_subtitle import WhisperSubtitleGenerator
                generator = WhisperSubtitleGenerator()
            else:
                generator = self.whisper_generator
            
            # Apply config - WITH DEBUG LOGGING
            font_size = config.get('font_size', 48)
            generator.config.font_size = font_size
            generator.config.font_color = config.get('font_color', (255, 255, 255))
            generator.config.outline_width = config.get('outline_width', 2)
            generator.config.outline_color = config.get('outline_color', (0, 0, 0))
            
            print(f"🔧 INFERENCE BACKEND DEBUG: Setting font_size = {font_size} from config")
            print(f"🔧 INFERENCE BACKEND DEBUG: Setting outline_width = {generator.config.outline_width}")
            print(f"🔧 INFERENCE BACKEND DEBUG: Setting outline_color = {generator.config.outline_color}")
            print(f"🔧 INFERENCE BACKEND DEBUG: Full config keys: {list(config.keys())}")
            
            # Handle background enabled/disabled
            background_enabled = config.get('background_enabled', True)
            background_color = config.get('background_color', (0, 0, 0, 128))
            if not background_enabled:
                # Disable background by setting alpha to 0
                background_color = (*background_color[:3], 0)
            generator.config.background_color = background_color
            
            print(f"🔧 DEBUG: Background enabled={background_enabled}, color={background_color}")
            
            generator.config.max_width_ratio = config.get('max_width_ratio', 0.8)  # Add max width ratio
            print(f"🔧 DEBUG: Set max_width_ratio = {generator.config.max_width_ratio} from config")
            
            position = config.get('position', 'Dưới cùng')
            if position == 'Dưới cùng':
                generator.config.position = 'bottom'
            elif position == 'Trên cùng':
                generator.config.position = 'top'
            else:
                generator.config.position = 'center'
                
            generator.config.margin_bottom = config.get('margin_bottom', 50)
            generator.config.margin_top = config.get('margin_top', 50)
            
            font_name = config.get('font_name', 'Arial')
            shadow_enabled = config.get('shadow_enabled', False)
            shadow_blur = config.get('shadow_blur', 3)
            shadow_color = config.get('shadow_color', (0, 0, 0))
            glow_enabled = config.get('glow_enabled', False)
            glow_intensity = config.get('glow_intensity', 5)
            glow_color = config.get('glow_color', (255, 255, 0))
            
            print(f"🔧 DEBUG: Shadow enabled={shadow_enabled}, blur={shadow_blur}, color={shadow_color}")
            print(f"🔧 DEBUG: Glow enabled={glow_enabled}, intensity={glow_intensity}, color={glow_color}")
            
            # Apply background settings - modify config directly
            background_enabled = config.get('background_enabled', True)
            if not background_enabled:
                # Temporarily override background color alpha to disable background
                original_bg_color = generator.config.background_color
                generator.config.background_color = (*original_bg_color[:3], 0)
            
            result = generator.draw_subtitle_on_frame(
                frame, subtitle_text, font_name,
                shadow_enabled, shadow_blur, shadow_color,
                glow_enabled, glow_intensity, glow_color
            )
            
            # Restore original background color if it was modified
            if not background_enabled:
                generator.config.background_color = original_bg_color
                
            return result
            
        except Exception as e:
            print(f"❌ Error in render_basic_subtitle: {e}")
            return frame
    
    def _add_text_overlays_to_frame(self, frame, current_time):
        """Add text overlays to frame at current time"""
        try:
            if not hasattr(self.args, 'text_overlays') or not self.args.text_overlays:
                return frame
            
            # Import text overlay processor
            from ui.backend.text_overlay_processor import TextOverlayProcessor
            
            # Create processor if not exists
            if not hasattr(self, '_text_overlay_processor'):
                self._text_overlay_processor = TextOverlayProcessor()
            
            # Apply text overlays
            result_frame = self._text_overlay_processor.apply_text_overlays(frame, self.args.text_overlays, current_time)
            return result_frame
            
        except Exception as e:
            print(f"❌ ERROR: Error adding text overlays: {e}")
            return frame
            print(f"Error rendering basic subtitle: {e}")
            return frame