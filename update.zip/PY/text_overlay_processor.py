"""
Text Overlay Processing Module - Xử lý thêm text overlay vào video
"""
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import os
import platform


class TextOverlayProcessor:
    """Class xử lý text overlay trên video frames"""
    
    def __init__(self):
        self.font_cache = {}
        self.system_fonts = self._get_system_fonts()
    
    def _get_system_fonts(self):
        """Get system fonts paths for different OS"""
        fonts = {}
        
        if platform.system() == "Windows":
            fonts_dir = "C:/Windows/Fonts/"
            font_mapping = {
                "Arial": "arial.ttf",
                "Times New Roman": "times.ttf", 
                "Verdana": "verdana.ttf",
                "Impact": "impact.ttf",
                "Comic Sans MS": "comic.ttf",
                "Georgia": "georgia.ttf",
                "Courier New": "cour.ttf"
            }
            
            for font_name, font_file in font_mapping.items():
                font_path = os.path.join(fonts_dir, font_file)
                if os.path.exists(font_path):
                    fonts[font_name] = font_path
                    
        elif platform.system() == "Darwin":  # macOS
            fonts_dirs = ["/System/Library/Fonts/", "/Library/Fonts/"]
            # Add macOS specific font mappings
        elif platform.system() == "Linux":
            fonts_dirs = ["/usr/share/fonts/", "/usr/local/share/fonts/"]
            # Add Linux specific font mappings
        
        return fonts
    
    def _get_font(self, font_name, font_size):
        """Get font object with caching"""
        cache_key = f"{font_name}_{font_size}"
        
        if cache_key in self.font_cache:
            return self.font_cache[cache_key]
        
        try:
            # Try to use system font
            if font_name in self.system_fonts:
                font = ImageFont.truetype(self.system_fonts[font_name], font_size)
            else:
                # Fallback to default font
                try:
                    font = ImageFont.truetype("arial.ttf", font_size)
                except:
                    font = ImageFont.load_default()
            
            # Cache font
            self.font_cache[cache_key] = font
            
            # Limit cache size
            if len(self.font_cache) > 20:
                oldest_key = next(iter(self.font_cache))
                del self.font_cache[oldest_key]
            
            return font
            
        except Exception as e:
            print(f"Error loading font {font_name}: {e}")
            return ImageFont.load_default()
    
    def apply_text_overlays(self, frame, overlays, current_time):
        """
        Apply all active text overlays to a frame
        
        Args:
            frame: OpenCV frame (BGR)
            overlays: List of TextOverlayItem objects
            current_time: Current time in seconds
            
        Returns:
            Modified frame with overlays applied
        """
        if not overlays:
            return frame
        
        # Get active overlays at current time
        active_overlays = []
        for overlay in overlays:
            if (overlay.enabled and 
                overlay.start_time <= current_time <= overlay.end_time):
                active_overlays.append(overlay)
        
        if not active_overlays:
            return frame
        
        # Convert OpenCV BGR to PIL RGB
        pil_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        
        # Apply each overlay
        for overlay in active_overlays:
            pil_image = self._apply_single_overlay(pil_image, overlay)
        
        # Convert back to OpenCV BGR
        result_frame = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        return result_frame
    
    def _apply_single_overlay(self, pil_image, overlay):
        """Apply single text overlay to PIL image"""
        try:
            # Get image dimensions
            img_width, img_height = pil_image.size
            
            # Scale font size based on image resolution
            reference_height = 1080
            font_scale = img_height / reference_height
            scaled_font_size = max(int(overlay.font_size * font_scale), 12)
            
            # Get font
            font = self._get_font(overlay.font_name, scaled_font_size)
            
            # Create drawing context
            if overlay.background_enabled and len(overlay.background_color) >= 4 and overlay.background_color[3] > 0:
                # Create overlay with alpha for background
                overlay_img = Image.new('RGBA', pil_image.size, (0, 0, 0, 0))
                draw = ImageDraw.Draw(overlay_img)
            else:
                # Draw directly on image
                pil_image = pil_image.convert('RGBA') if pil_image.mode != 'RGBA' else pil_image
                draw = ImageDraw.Draw(pil_image)
                overlay_img = None
            
            # Text wrapping and positioning
            text_lines = self._wrap_text(overlay.text, font, img_width * 0.9, draw)
            
            # Calculate total text dimensions
            line_heights = []
            line_widths = []
            
            for line in text_lines:
                bbox = draw.textbbox((0, 0), line, font=font)
                line_heights.append(bbox[3] - bbox[1])
                line_widths.append(bbox[2] - bbox[0])
            
            max_line_width = max(line_widths) if line_widths else 0
            total_height = sum(line_heights) + (len(text_lines) - 1) * int(max(line_heights) * 0.2) if line_heights else 0
            
            # Calculate position
            x = int(overlay.x_position * img_width - max_line_width / 2)
            y = int(overlay.y_position * img_height - total_height / 2)
            
            # Ensure text stays within bounds
            x = max(10, min(x, img_width - max_line_width - 10))
            y = max(10, min(y, img_height - total_height - 10))
            
            # Draw background if enabled
            if overlay.background_enabled and len(overlay.background_color) >= 4 and overlay.background_color[3] > 0:
                bg_padding = int(overlay.background_padding * font_scale)
                bg_x1 = x - bg_padding
                bg_y1 = y - bg_padding
                bg_x2 = x + max_line_width + bg_padding
                bg_y2 = y + total_height + bg_padding
                
                bg_color = overlay.background_color[:3]
                bg_alpha = overlay.background_color[3]
                
                if overlay_img:
                    draw.rectangle([bg_x1, bg_y1, bg_x2, bg_y2], fill=(*bg_color, bg_alpha))
                else:
                    # Create background overlay
                    bg_overlay = Image.new('RGBA', pil_image.size, (0, 0, 0, 0))
                    bg_draw = ImageDraw.Draw(bg_overlay)
                    bg_draw.rectangle([bg_x1, bg_y1, bg_x2, bg_y2], fill=(*bg_color, bg_alpha))
                    pil_image = Image.alpha_composite(pil_image, bg_overlay)
                    draw = ImageDraw.Draw(pil_image)
            
            # Draw text lines
            current_y = y
            for i, line in enumerate(text_lines):
                line_width = line_widths[i]
                line_height = line_heights[i]
                
                # Center each line horizontally
                line_x = x + (max_line_width - line_width) // 2
                
                # Draw outline if enabled
                if overlay.outline_enabled and overlay.outline_width > 0:
                    outline_width = max(1, int(overlay.outline_width * font_scale))
                    outline_color = overlay.outline_color
                    
                    for dx in range(-outline_width, outline_width + 1):
                        for dy in range(-outline_width, outline_width + 1):
                            if dx != 0 or dy != 0:
                                if overlay_img:
                                    draw.text((line_x + dx, current_y + dy), line, 
                                            font=font, fill=(*outline_color, 255))
                                else:
                                    draw.text((line_x + dx, current_y + dy), line, 
                                            font=font, fill=outline_color)
                
                # Draw main text
                if overlay_img:
                    draw.text((line_x, current_y), line, 
                            font=font, fill=(*overlay.font_color, 255))
                else:
                    draw.text((line_x, current_y), line, 
                            font=font, fill=overlay.font_color)
                
                # Move to next line
                current_y += line_height + int(max(line_heights) * 0.2) if i < len(text_lines) - 1 else 0
            
            # Composite overlay if used
            if overlay_img:
                pil_image = pil_image.convert('RGBA') if pil_image.mode != 'RGBA' else pil_image
                pil_image = Image.alpha_composite(pil_image, overlay_img)
            
            # Convert back to RGB if needed
            if pil_image.mode == 'RGBA':
                rgb_image = Image.new('RGB', pil_image.size, (0, 0, 0))
                rgb_image.paste(pil_image, mask=pil_image.split()[3])
                pil_image = rgb_image
            
            return pil_image
            
        except Exception as e:
            print(f"Error applying text overlay: {e}")
            return pil_image
    
    def _wrap_text(self, text, font, max_width, draw):
        """Wrap text to fit within max_width"""
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            test_line = current_line + " " + word if current_line else word
            bbox = draw.textbbox((0, 0), test_line, font=font)
            test_width = bbox[2] - bbox[0]
            
            if test_width <= max_width:
                current_line = test_line
            else:
                if current_line:
                    lines.append(current_line)
                current_line = word
        
        if current_line:
            lines.append(current_line)
        
        return lines if lines else [text]
    
    def get_overlays_at_time(self, overlays, time_seconds):
        """Get list of active overlays at specific time"""
        active_overlays = []
        for overlay in overlays:
            if (overlay.enabled and 
                overlay.start_time <= time_seconds <= overlay.end_time):
                active_overlays.append(overlay)
        return active_overlays
    
    def clear_font_cache(self):
        """Clear font cache to free memory"""
        self.font_cache.clear()