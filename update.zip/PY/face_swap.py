#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Face Swap: YuNet + ArcFace + (inswapper_128 | simswap_512) + CodeFormer.
"""
import argparse, json, sys, os
import cv2
import numpy as np
import onnxruntime as ort


def imread_unicode(path):
    """cv2.imread replacement that supports Unicode paths on Windows."""
    data = np.fromfile(path, dtype=np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def imwrite_unicode(path, img, params=None):
    """cv2.imwrite replacement that supports Unicode paths on Windows."""
    ext = os.path.splitext(path)[1]
    result, buf = cv2.imencode(ext, img, params or [])
    if result:
        buf.tofile(path)
    return result

# ── Alignment templates (from FaceFusion) ──
TEMPLATES = {
    'arcface_112_v2': np.array([
        [0.34191607, 0.46157411], [0.65653393, 0.45983393],
        [0.50022500, 0.64050536], [0.37097589, 0.82469196],
        [0.63151696, 0.82325089]], dtype=np.float32),
    'arcface_128': np.array([
        [0.36167656, 0.40387734], [0.63696719, 0.40235469],
        [0.50019687, 0.56044219], [0.38710391, 0.72160547],
        [0.61507734, 0.72034453]], dtype=np.float32),
}


def load_config(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


def warp_face(img, lmk, template_name, crop_size):
    template = TEMPLATES[template_name] * np.array(crop_size, dtype=np.float32)
    src = np.array(lmk, dtype=np.float32).reshape(5, 2)
    M = cv2.estimateAffinePartial2D(src, template, method=cv2.RANSAC,
                                     ransacReprojThreshold=100)[0]
    crop = cv2.warpAffine(img, M, crop_size,
                          borderMode=cv2.BORDER_REPLICATE, flags=cv2.INTER_AREA)
    return crop, M


def detect_faces(img, yunet_path):
    h, w = img.shape[:2]
    det = cv2.FaceDetectorYN.create(yunet_path, "", (w, h), 0.5, 0.3, 5000)
    _, raw = det.detect(img)
    if raw is None or len(raw) == 0:
        return []
    faces = []
    for row in raw:
        lmk = np.array([[float(row[4+i*2]), float(row[4+i*2+1])] for i in range(5)], np.float32)
        faces.append({'kps': lmk, 'score': float(row[14])})
    faces.sort(key=lambda f: f['score'], reverse=True)
    return faces


def get_embedding(img, kps, arc_sess):
    aligned, _ = warp_face(img, kps, 'arcface_112_v2', (112, 112))
    blob = cv2.dnn.blobFromImage(aligned, 1.0/127.5, (112,112),
                                  (127.5,127.5,127.5), swapRB=True)
    emb = arc_sess.run(None, {arc_sess.get_inputs()[0].name: blob})[0].flatten()
    norm = np.linalg.norm(emb) + 1e-5
    return emb, emb / norm


# ─── InSwapper 128 ───
class InSwapper:
    def __init__(self, path, providers):
        import onnx
        from onnx import numpy_helper
        model = onnx.load(path)
        self.emap = numpy_helper.to_array(model.graph.initializer[-1])
        self.sess = ort.InferenceSession(path, providers=providers)
        self.size = (128, 128)
        self.template = 'arcface_128'
        self.names_in = [i.name for i in self.sess.get_inputs()]
        self.names_out = [o.name for o in self.sess.get_outputs()]

    def run(self, img, kps, raw_emb, norm_emb):
        aimg, M = warp_face(img, kps, self.template, self.size)
        inp = aimg[:, :, ::-1].astype(np.float32) / 255.0
        inp = inp.transpose(2, 0, 1)[np.newaxis, ...]
        source = raw_emb.reshape(1, -1).astype(np.float32)
        latent = np.dot(source, self.emap) / (np.linalg.norm(source) + 1e-5)
        pred = self.sess.run(self.names_out,
                             {self.names_in[0]: inp, self.names_in[1]: latent})[0][0]
        out = pred.transpose(1, 2, 0).clip(0, 1)
        out = (out[:, :, ::-1] * 255).astype(np.uint8)
        return out, M


# ─── CodeFormer 512 ───
class CodeFormerEnhancer:
    def __init__(self, path, providers):
        self.sess = ort.InferenceSession(path, providers=providers)

    def enhance(self, face_img):
        inp = cv2.resize(face_img, (512, 512))
        blob = inp[:, :, ::-1].astype(np.float32) / 255.0
        blob = (blob - 0.5) / 0.5
        blob = blob.transpose(2, 0, 1)[np.newaxis, ...]
        inputs = {self.sess.get_inputs()[0].name: blob}
        if len(self.sess.get_inputs()) > 1:
            w_name = self.sess.get_inputs()[1].name
            inputs[w_name] = np.array([0.5], dtype=np.float64)
        out = self.sess.run(None, inputs)[0][0]
        result = out.transpose(1, 2, 0)
        result = (result * 0.5 + 0.5).clip(0, 1)
        result = (result * 255).astype(np.uint8)
        return result[:, :, ::-1]


def paste_back(img, swapped, M, face_size):
    """Paste swapped face back using seamless clone + gradient mask."""
    h, w = img.shape[:2]
    sz = face_size

    # Create smooth elliptical mask
    mask = np.zeros((sz, sz), np.float32)
    cv2.ellipse(mask, (sz//2, sz//2), (int(sz*0.42), int(sz*0.48)),
                0, 0, 360, 1.0, -1)
    k = max(sz // 5 | 1, 3)
    if k % 2 == 0:
        k += 1
    mask = cv2.GaussianBlur(mask, (k, k), sz * 0.1)

    iM = cv2.invertAffineTransform(M)
    warped = cv2.warpAffine(swapped, iM, (w, h), borderMode=cv2.BORDER_REPLICATE)
    mask_u8 = (mask * 255).astype(np.uint8)
    wmask = cv2.warpAffine(mask_u8, iM, (w, h))

    # Seamless clone
    nz = cv2.findNonZero(wmask)
    if nz is not None and len(nz) > 10:
        m = cv2.moments(wmask)
        if m['m00'] > 0:
            cx = max(1, min(int(m['m10']/m['m00']), w-2))
            cy = max(1, min(int(m['m01']/m['m00']), h-2))
            try:
                return cv2.seamlessClone(warped, img, wmask, (cx, cy), cv2.NORMAL_CLONE)
            except Exception:
                pass
    # Fallback: alpha blend
    wm = (wmask.astype(np.float32) / 255.0)[:, :, None]
    return (warped * wm + img * (1 - wm)).astype(np.uint8)


def find_model(model_dir, filename):
    """Search for model file in model_dir root and models/ subfolder."""
    p = os.path.join(model_dir, filename)
    if os.path.exists(p):
        return p
    p2 = os.path.join(model_dir, "models", filename)
    if os.path.exists(p2):
        return p2
    return None


def ensure_model(model_dir, repo, filename, label):
    p = os.path.join(model_dir, filename)
    if not os.path.exists(p):
        print(f"[FaceSwap] Downloading {label}...", flush=True)
        from huggingface_hub import hf_hub_download
        hf_hub_download(repo, filename=filename, local_dir=model_dir)
    return p


def run(cfg):
    src_path, tgt_path = cfg['source'], cfg['target']
    out_path = cfg['output']
    model_dir = cfg.get('model_path', '')
    enhance = cfg.get('enhance', False)
    model_name = cfg.get('model_name', 'inswapper')

    for label, p in [("Source", src_path), ("Target", tgt_path)]:
        if not os.path.exists(p):
            print(f"[FaceSwap] ERROR: {label} not found: {p}", file=sys.stderr, flush=True)
            return False

    providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']

    # YuNet face detector
    yunet_path = find_model(model_dir, "face_detection_yunet_2023mar.onnx")
    if not yunet_path:
        yunet_path = os.path.join(model_dir, "face_detection_yunet_2023mar.onnx")
        import urllib.request
        os.makedirs(model_dir, exist_ok=True)
        urllib.request.urlretrieve(
            "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
            yunet_path)

    # ArcFace embedding
    arcface_path = find_model(model_dir, "w600k_r50.onnx")
    if not arcface_path:
        arcface_path = os.path.join(model_dir, "models", "buffalo_l", "w600k_r50.onnx")
        if not os.path.exists(arcface_path):
            ensure_model(model_dir, 'public-data/insightface',
                         'models/buffalo_l/w600k_r50.onnx', 'ArcFace')

    # Swap model
    swap_path = find_model(model_dir, "inswapper_128.onnx")
    if not swap_path:
        swap_path = ensure_model(model_dir, 'ezioruan/inswapper_128.onnx',
                                 'inswapper_128.onnx', 'InSwapper 128')

    if not swap_path or not os.path.exists(swap_path):
        print(f"[FaceSwap] ERROR: Swap model not found", file=sys.stderr, flush=True)
        return False

    print(f"[FaceSwap] Model: {os.path.basename(swap_path)}", flush=True)
    src_img = imread_unicode(src_path)
    tgt_img = imread_unicode(tgt_path)
    if src_img is None or tgt_img is None:
        print("[FaceSwap] ERROR: Cannot read image(s)", file=sys.stderr, flush=True)
        return False

    print("[FaceSwap] Detecting faces...", flush=True)
    src_faces = detect_faces(src_img, yunet_path)
    if not src_faces:
        print("[FaceSwap] ERROR: No face in source!", file=sys.stderr, flush=True)
        return False
    tgt_faces = detect_faces(tgt_img, yunet_path)
    if not tgt_faces:
        print("[FaceSwap] ERROR: No face in target!", file=sys.stderr, flush=True)
        return False
    print(f"[FaceSwap] Source: 1 face, Target: {len(tgt_faces)} face(s)", flush=True)

    print("[FaceSwap] Computing embeddings...", flush=True)
    arc_sess = ort.InferenceSession(arcface_path, providers=providers)
    src_raw, src_norm = get_embedding(src_img, src_faces[0]['kps'], arc_sess)

    print("[FaceSwap] Loading swapper...", flush=True)
    swapper = InSwapper(swap_path, providers)

    # CodeFormer
    enhancer = None
    if enhance:
        cf_path = find_model(model_dir, "codeformer.onnx")
        if not cf_path:
            cf_path = ensure_model(model_dir, 'facefusion/models-3.0.0',
                                   'codeformer.onnx', 'CodeFormer')
        if cf_path and os.path.exists(cf_path):
            print("[FaceSwap] Loading CodeFormer...", flush=True)
            enhancer = CodeFormerEnhancer(cf_path, providers)

    result = tgt_img.copy()
    for i, face in enumerate(tgt_faces):
        print(f"[FaceSwap] Swapping face {i+1}/{len(tgt_faces)}...", flush=True)
        out, M = swapper.run(result, face['kps'], src_raw, src_norm)
        face_size = out.shape[0]

        if enhancer:
            print(f"[FaceSwap] Enhancing face {i+1} with CodeFormer...", flush=True)
            enhanced = enhancer.enhance(out)
            out = cv2.resize(enhanced, (face_size, face_size))

        result = paste_back(result, out, M, face_size)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    imwrite_unicode(out_path, result, [cv2.IMWRITE_JPEG_QUALITY, 98])
    print(f"[FaceSwap] Done! {out_path}", flush=True)
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    try:
        ok = run(cfg)
        print("[FaceSwap] SUCCESS" if ok else "[FaceSwap] FAILED", flush=True)
        sys.exit(0 if ok else 1)
    except Exception as e:
        print(f"[FaceSwap] ERROR: {e}", file=sys.stderr, flush=True)
        import traceback; traceback.print_exc(file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
