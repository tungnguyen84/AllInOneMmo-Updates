#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Wav2Lip HD inference wrapper.
Downloads models from GitHub and generates lip-synced video.
Only modifies the mouth region — body stays pixel-perfect.
"""
import argparse, json, sys, os, shutil, subprocess, tempfile
import numpy as np


def load_config(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


# ============ Model download ============
WAV2LIP_MODEL_URL = "https://huggingface.co/numz/wav2lip_studio/resolve/main/Wav2lip/wav2lip_gan.pth"


def download_file(url, dest, label="file"):
    """Download with progress."""
    import urllib.request
    if os.path.exists(dest):
        print(f"[Wav2Lip] {label} already exists, skip.", flush=True)
        return True
    print(f"[Wav2Lip] Downloading {label}...", flush=True)
    try:
        urllib.request.urlretrieve(url, dest)
        print(f"[Wav2Lip] Downloaded {label} OK ({os.path.getsize(dest) / 1024 / 1024:.1f} MB)", flush=True)
        return True
    except Exception as e:
        print(f"[Wav2Lip] Failed to download {label}: {e}", file=sys.stderr, flush=True)
        return False


def ensure_models(wav2lip_dir):
    """Download wav2lip_gan.pth model."""
    checkpoints_dir = os.path.join(wav2lip_dir, "checkpoints")
    os.makedirs(checkpoints_dir, exist_ok=True)

    # Wav2Lip GAN model
    wav2lip_path = os.path.join(checkpoints_dir, "wav2lip_gan.pth")
    if not download_file(WAV2LIP_MODEL_URL, wav2lip_path, "wav2lip_gan.pth"):
        return False

    print("[Wav2Lip] All models ready!", flush=True)
    return True


# ============ Face detection ============
def get_face_box(image, detector):
    """Detect face using OpenCV DNN (fallback) or dlib."""
    import cv2
    h, w = image.shape[:2]

    # Use OpenCV DNN face detector (bundled, no extra deps)
    model_file = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    if os.path.exists(model_file):
        cascade = cv2.CascadeClassifier(model_file)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(80, 80))
        if len(faces) > 0:
            # Pick largest face
            faces = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)
            x, y, fw, fh = faces[0]
            return (y, y + fh, x, x + fw)

    # Fallback: assume center crop
    cy, cx = h // 2, w // 2
    size = min(h, w) // 2
    return (max(0, cy - size), min(h, cy + size), max(0, cx - size), min(w, cx + size))


# ============ Inference ============
def run_inference(cfg):
    """Run Wav2Lip inference: detect face, sync lips, paste back."""
    import cv2
    import torch

    source_path = cfg['video_path']  # image or video
    audio_path = cfg['audio_path']
    output_path = cfg['output_path']
    wav2lip_dir = os.path.normpath(cfg.get('wav2lip_dir', ''))

    # Validate inputs
    for label, p in [("Image/Video", source_path), ("Audio", audio_path)]:
        if not os.path.exists(p):
            print(f"[Wav2Lip] ERROR: {label} not found: {p}", file=sys.stderr, flush=True)
            return False

    # Ensure models
    if not ensure_models(wav2lip_dir):
        return False

    # Add wav2lip dir to path
    if wav2lip_dir not in sys.path:
        sys.path.insert(0, wav2lip_dir)

    checkpoint_path = os.path.join(wav2lip_dir, "checkpoints", "wav2lip_gan.pth")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[Wav2Lip] Device: {device}", flush=True)

    # Determine if input is image or video
    ext = os.path.splitext(source_path)[1].lower()
    is_image = ext in ('.jpg', '.jpeg', '.png', '.bmp', '.webp')

    # Load source frames
    print("[Wav2Lip] Loading source...", flush=True)
    if is_image:
        img = cv2.imread(source_path)
        if img is None:
            print("[Wav2Lip] ERROR: Cannot read image", file=sys.stderr, flush=True)
            return False
        source_frames = [img]
        fps = 25
        orig_h, orig_w = img.shape[:2]
    else:
        cap = cv2.VideoCapture(source_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        source_frames = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            source_frames.append(frame)
        cap.release()
        if not source_frames:
            print("[Wav2Lip] ERROR: Cannot read video frames", file=sys.stderr, flush=True)
            return False
        orig_h, orig_w = source_frames[0].shape[:2]

    # Process audio to mel spectrogram
    print("[Wav2Lip] Processing audio...", flush=True)

    # Convert audio to wav 16kHz mono using ffmpeg
    temp_wav = os.path.join(tempfile.gettempdir(), f"wav2lip_audio_{os.getpid()}.wav")
    try:
        subprocess.run([
            "ffmpeg", "-y", "-i", audio_path,
            "-ar", "16000", "-ac", "1", "-f", "wav", temp_wav
        ], capture_output=True, check=True)
    except Exception as e:
        print(f"[Wav2Lip] ERROR converting audio: {e}", file=sys.stderr, flush=True)
        return False

    # Load audio and compute mel
    try:
        from wav2lip import audio as wav2lip_audio
        wav = wav2lip_audio.load_wav(temp_wav, 16000)
        mel = wav2lip_audio.melspectrogram(wav)
    except ImportError:
        # Fallback: inline mel computation
        import scipy.io.wavfile as wavfile
        sr, wav_data = wavfile.read(temp_wav)
        if wav_data.dtype != np.float32:
            wav_data = wav_data.astype(np.float32) / 32768.0
        if len(wav_data.shape) > 1:
            wav_data = wav_data.mean(axis=1)

        # Simple mel spectrogram using librosa if available
        try:
            import librosa
            mel = librosa.feature.melspectrogram(y=wav_data, sr=16000, n_fft=800,
                                                  hop_length=200, n_mels=80)
            mel = librosa.power_to_db(mel, ref=np.max)
        except ImportError:
            print("[Wav2Lip] ERROR: Need librosa or wav2lip audio module", file=sys.stderr, flush=True)
            return False

    print(f"[Wav2Lip] Mel shape: {mel.shape}", flush=True)

    # Load Wav2Lip model
    print("[Wav2Lip] Loading Wav2Lip model...", flush=True)
    try:
        from wav2lip.models import Wav2Lip as Wav2LipModel
        model = Wav2LipModel()
        ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
        s = ckpt.get("state_dict", ckpt)
        new_s = {}
        for k, v in s.items():
            new_s[k.replace('module.', '')] = v
        model.load_state_dict(new_s)
        model = model.to(device).eval()
    except ImportError:
        # If wav2lip package not bundled, use generic torch approach
        print("[Wav2Lip] Loading model with torch.load...", flush=True)
        model = torch.load(checkpoint_path, map_location=device, weights_only=False)
        if hasattr(model, 'eval'):
            model = model.to(device).eval()

    # Calculate number of output frames based on mel length
    mel_step_size = 16  # Wav2Lip uses 16 mel frames per video frame
    mel_chunks = []
    mel_idx_multiplier = 80.0 / fps  # mel frames per video frame
    i = 0
    while True:
        start_idx = int(i * mel_idx_multiplier)
        if start_idx + mel_step_size > mel.shape[1]:
            mel_chunks.append(mel[:, -mel_step_size:])
            break
        mel_chunks.append(mel[:, start_idx:start_idx + mel_step_size])
        i += 1

    num_output_frames = len(mel_chunks)
    print(f"[Wav2Lip] Output frames: {num_output_frames}", flush=True)

    # Detect face on first frame
    print("[Wav2Lip] Detecting face...", flush=True)
    face_box = get_face_box(source_frames[0], None)
    if face_box is None:
        print("[Wav2Lip] ERROR: No face detected", file=sys.stderr, flush=True)
        return False

    y1, y2, x1, x2 = face_box
    # Add padding
    pad_h = int((y2 - y1) * 0.1)
    pad_w = int((x2 - x1) * 0.1)
    y1 = max(0, y1 - pad_h)
    y2 = min(orig_h, y2 + pad_h)
    x1 = max(0, x1 - pad_w)
    x2 = min(orig_w, x2 + pad_w)

    print(f"[Wav2Lip] Face region: ({x1},{y1})-({x2},{y2})", flush=True)

    # Generate lip-synced frames
    print("[Wav2Lip] Generating lip-synced frames...", flush=True)
    img_size = 96  # Wav2Lip uses 96x96
    batch_size = 8

    output_dir = os.path.dirname(os.path.abspath(output_path))
    os.makedirs(output_dir, exist_ok=True)

    temp_video = os.path.join(tempfile.gettempdir(), f"wav2lip_temp_{os.getpid()}.avi")
    fourcc = cv2.VideoWriter_fourcc(*'MJPG')
    writer = cv2.VideoWriter(temp_video, fourcc, fps, (orig_w, orig_h))

    with torch.no_grad():
        for batch_start in range(0, num_output_frames, batch_size):
            batch_end = min(batch_start + batch_size, num_output_frames)

            img_batch = []
            mel_batch = []
            frame_batch = []
            coords_batch = []

            for idx in range(batch_start, batch_end):
                # Get source frame (loop if image)
                frame_idx = idx % len(source_frames)
                frame = source_frames[frame_idx].copy()

                # Crop face
                face = frame[y1:y2, x1:x2]
                face_resized = cv2.resize(face, (img_size, img_size))

                img_batch.append(face_resized)
                mel_batch.append(mel_chunks[idx])
                frame_batch.append(frame)
                coords_batch.append((y1, y2, x1, x2))

            # Prepare tensors
            img_batch_np = np.array(img_batch, dtype=np.float32) / 255.0
            mel_batch_np = np.array(mel_batch, dtype=np.float32)

            # Wav2Lip expects: img (B, 6, 96, 96), mel (B, 1, 80, 16)
            # Lower half masked
            img_masked = img_batch_np.copy()
            img_masked[:, img_size // 2:, :, :] = 0  # mask lower half

            img_tensor = np.concatenate([img_masked, img_batch_np], axis=3)  # (B, 96, 96, 6)
            img_tensor = np.transpose(img_tensor, (0, 3, 1, 2))  # (B, 6, 96, 96)

            mel_tensor = mel_batch_np[:, np.newaxis, :, :]  # (B, 1, 80, 16)

            img_tensor = torch.FloatTensor(img_tensor).to(device)
            mel_tensor = torch.FloatTensor(mel_tensor).to(device)

            # Forward pass
            try:
                pred = model(mel_tensor, img_tensor)
            except Exception as e:
                print(f"[Wav2Lip] Model forward error: {e}", file=sys.stderr, flush=True)
                # Write original frames as fallback
                for frame in frame_batch:
                    writer.write(frame)
                continue

            pred = pred.cpu().numpy()
            pred = (pred * 255).astype(np.uint8)
            pred = np.transpose(pred, (0, 2, 3, 1))  # (B, 96, 96, 3)

            # Paste back
            for i, frame in enumerate(frame_batch):
                fy1, fy2, fx1, fx2 = coords_batch[i]
                face_h = fy2 - fy1
                face_w = fx2 - fx1
                pred_face = cv2.resize(pred[i], (face_w, face_h))

                # Only paste lower half (mouth region) for smoother blending
                mouth_start = face_h // 2 - face_h // 8  # slightly above center
                blend_zone = face_h // 10  # smooth blend zone

                for row in range(mouth_start, face_h):
                    alpha = 1.0
                    if row < mouth_start + blend_zone:
                        alpha = (row - mouth_start) / blend_zone

                    row_y = fy1 + row
                    if 0 <= row_y < orig_h:
                        frame[row_y, fx1:fx2] = (
                            alpha * pred_face[row] + (1 - alpha) * frame[row_y, fx1:fx2]
                        ).astype(np.uint8)

                writer.write(frame)

            if (batch_start // batch_size) % 10 == 0:
                progress = min(100, int(batch_end / num_output_frames * 100))
                print(f"[Wav2Lip] Progress: {progress}%", flush=True)

    writer.release()

    # Mux audio with video using ffmpeg
    print("[Wav2Lip] Muxing audio with video...", flush=True)
    try:
        subprocess.run([
            "ffmpeg", "-y",
            "-i", temp_video,
            "-i", audio_path,
            "-c:v", "libx264", "-preset", "fast", "-crf", "18",
            "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            output_path
        ], capture_output=True, check=True)
    except Exception as e:
        # Fallback: just copy the video without re-encoding audio
        shutil.copy2(temp_video, output_path)
        print(f"[Wav2Lip] Warning: Could not mux audio: {e}", flush=True)

    # Cleanup
    try:
        if os.path.exists(temp_wav):
            os.remove(temp_wav)
        if os.path.exists(temp_video):
            os.remove(temp_video)
    except Exception:
        pass

    if os.path.exists(output_path):
        print(f"[Wav2Lip] Done! Output: {output_path}", flush=True)
        return True
    else:
        print("[Wav2Lip] ERROR: No output file generated", file=sys.stderr, flush=True)
        return False


# ============ Main ============
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)

    mode = cfg.get('mode', 'inference')
    if mode == 'download':
        wav2lip_dir = os.path.normpath(cfg.get('wav2lip_dir', ''))
        ok = ensure_models(wav2lip_dir)
    else:
        ok = run_inference(cfg)

    print("[Wav2Lip] SUCCESS" if ok else "[Wav2Lip] FAILED", flush=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
