#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Upscale images using ESRGAN (RRDBNet) models like NMKD-Siax.
Supports tile-based upscaling for low VRAM usage.
"""
import argparse, json, sys, os
import numpy as np

def load_config(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


def imread_unicode(path):
    """Read image from Unicode path."""
    import cv2
    data = np.fromfile(path, dtype=np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)


def imwrite_unicode(path, img, params=None):
    """Write image to Unicode path."""
    import cv2
    ext = os.path.splitext(path)[1]
    result, buf = cv2.imencode(ext, img, params or [])
    if result:
        buf.tofile(path)
    return result


# ─── RRDBNet architecture (same as ESRGAN) ───
import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualDenseBlock(nn.Module):
    def __init__(self, nf=64, gc=32):
        super().__init__()
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat([x, x1], 1)))
        x3 = self.lrelu(self.conv3(torch.cat([x, x1, x2], 1)))
        x4 = self.lrelu(self.conv4(torch.cat([x, x1, x2, x3], 1)))
        x5 = self.conv5(torch.cat([x, x1, x2, x3, x4], 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    def __init__(self, nf=64, gc=32):
        super().__init__()
        self.rdb1 = ResidualDenseBlock(nf, gc)
        self.rdb2 = ResidualDenseBlock(nf, gc)
        self.rdb3 = ResidualDenseBlock(nf, gc)

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return out * 0.2 + x


class RRDBNet(nn.Module):
    def __init__(self, in_nc=3, out_nc=3, nf=64, nb=23, gc=32, scale=4):
        super().__init__()
        self.scale = scale
        self.conv_first = nn.Conv2d(in_nc, nf, 3, 1, 1)
        self.body = nn.Sequential(*[RRDB(nf, gc) for _ in range(nb)])
        self.conv_body = nn.Conv2d(nf, nf, 3, 1, 1)
        # Upsampling
        self.conv_up1 = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_hr = nn.Conv2d(nf, nf, 3, 1, 1)
        self.conv_last = nn.Conv2d(nf, out_nc, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        fea = self.conv_first(x)
        trunk = self.conv_body(self.body(fea))
        fea = fea + trunk
        fea = self.lrelu(self.conv_up1(F.interpolate(fea, scale_factor=2, mode='nearest')))
        fea = self.lrelu(self.conv_up2(F.interpolate(fea, scale_factor=2, mode='nearest')))
        out = self.conv_last(self.lrelu(self.conv_hr(fea)))
        return out


# ─── Target resolutions ───
RESOLUTIONS = {
    '1080p': (1920, 1080),
    '2k':    (2560, 1440),
    '4k':    (3840, 2160),
}


def download_model(model_dir):
    """Download NMKD-Siax model if not present."""
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, '4x_NMKD-Siax_200k.pth')
    if os.path.exists(model_path):
        return model_path

    print("[Upscale] Downloading 4x_NMKD-Siax_200k model (~65MB)...", flush=True)
    import urllib.request
    url = "https://huggingface.co/uwg/upscaler/resolve/main/ESRGAN/4x_NMKD-Siax_200k.pth"
    try:
        urllib.request.urlretrieve(url, model_path)
        print("[Upscale] Model downloaded successfully!", flush=True)
    except Exception:
        # Fallback: try alternative repo
        print("[Upscale] Primary URL failed, trying fallback...", flush=True)
        url2 = "https://huggingface.co/gemasai/4x_NMKD-Siax_200k/resolve/main/4x_NMKD-Siax_200k.pth"
        urllib.request.urlretrieve(url2, model_path)
        print("[Upscale] Model downloaded via fallback URL!", flush=True)

    return model_path


def load_model(model_path, device):
    """Load ESRGAN/RRDBNet model from .pth file, handling old/new key formats."""
    print(f"[Upscale] Loading model: {os.path.basename(model_path)}", flush=True)
    state_dict = torch.load(model_path, map_location='cpu', weights_only=True)

    # Check if old ESRGAN format (keys start with 'model.')
    if any(k.startswith('model.') for k in state_dict.keys()):
        print("[Upscale] Converting old ESRGAN key format...", flush=True)
        state_dict = convert_old_esrgan_keys(state_dict)

    # Detect num_blocks from state_dict keys
    nb = 0
    for key in state_dict:
        if key.startswith('body.') and '.rdb' in key:
            idx = int(key.split('.')[1])
            nb = max(nb, idx + 1)
    if nb == 0:
        nb = 23  # default

    model = RRDBNet(in_nc=3, out_nc=3, nf=64, nb=nb, gc=32, scale=4)
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    model = model.to(device)
    print(f"[Upscale] Model loaded ({nb} RRDB blocks), device={device}", flush=True)
    return model


def convert_old_esrgan_keys(old_state_dict):
    """
    Convert old ESRGAN state_dict keys to new RRDBNet format.
    Old format: model.0.weight → conv_first.weight
                model.1.sub.{n}.RDB{m}.conv{k}.0.weight → body.{n}.rdb{m}.conv{k}.weight
                model.1.sub.{nb}.weight → conv_body.weight
                model.3.weight → conv_up1.weight
                model.6.weight → conv_up2.weight
                model.8.weight → conv_hr.weight
                model.10.weight → conv_last.weight
    """
    new_state_dict = {}
    # Find the number of RRDB blocks (model.1.sub.{max_n} where max_n has RDB keys)
    max_sub = 0
    for key in old_state_dict:
        if key.startswith('model.1.sub.') and '.RDB' in key:
            idx = int(key.split('.')[3])
            max_sub = max(max_sub, idx)

    nb = max_sub + 1  # number of RRDB blocks

    for old_key, value in old_state_dict.items():
        new_key = old_key

        # conv_first
        if old_key.startswith('model.0.'):
            new_key = old_key.replace('model.0.', 'conv_first.')

        # RRDB blocks: model.1.sub.{n}.RDB{m}.conv{k}.0.{w/b}
        elif old_key.startswith('model.1.sub.') and '.RDB' in old_key:
            # Parse: model.1.sub.{n}.RDB{m}.conv{k}.0.{param}
            parts = old_key.split('.')
            block_idx = parts[3]   # n
            rdb_name = parts[4]    # RDB1, RDB2, RDB3
            conv_name = parts[5]   # conv1..conv5
            # parts[6] = '0' (sequential wrapper)
            param = parts[7]       # weight or bias
            rdb_lower = rdb_name.lower()  # rdb1, rdb2, rdb3
            new_key = f"body.{block_idx}.{rdb_lower}.{conv_name}.{param}"

        # conv_body: model.1.sub.{nb}.{w/b}
        elif old_key.startswith(f'model.1.sub.{nb}.'):
            new_key = old_key.replace(f'model.1.sub.{nb}.', 'conv_body.')

        # conv_up1
        elif old_key.startswith('model.3.'):
            new_key = old_key.replace('model.3.', 'conv_up1.')

        # conv_up2
        elif old_key.startswith('model.6.'):
            new_key = old_key.replace('model.6.', 'conv_up2.')

        # conv_hr
        elif old_key.startswith('model.8.'):
            new_key = old_key.replace('model.8.', 'conv_hr.')

        # conv_last
        elif old_key.startswith('model.10.'):
            new_key = old_key.replace('model.10.', 'conv_last.')

        new_state_dict[new_key] = value

    return new_state_dict


def upscale_tile(model, img_tensor, tile_size=512, tile_pad=32, device='cuda'):
    """
    Tile-based upscale to reduce VRAM usage.
    Processes image in overlapping tiles and blends results.
    """
    scale = 4
    _, _, h, w = img_tensor.shape
    output_h, output_w = h * scale, w * scale
    output = torch.zeros(1, 3, output_h, output_w, device='cpu')
    tile_weight = torch.zeros(1, 1, output_h, output_w, device='cpu')

    tiles_x = max(1, (w + tile_size - 1) // tile_size)
    tiles_y = max(1, (h + tile_size - 1) // tile_size)
    total = tiles_x * tiles_y
    count = 0

    for yi in range(tiles_y):
        for xi in range(tiles_x):
            # Input tile coordinates
            x_start = xi * tile_size
            y_start = yi * tile_size
            x_end = min(x_start + tile_size, w)
            y_end = min(y_start + tile_size, h)

            # Add padding
            x_start_pad = max(0, x_start - tile_pad)
            y_start_pad = max(0, y_start - tile_pad)
            x_end_pad = min(w, x_end + tile_pad)
            y_end_pad = min(h, y_end + tile_pad)

            # Extract and process tile
            tile_input = img_tensor[:, :, y_start_pad:y_end_pad, x_start_pad:x_end_pad].to(device)
            with torch.no_grad():
                tile_output = model(tile_input).cpu()

            # Output tile coordinates (scaled)
            ox_start = (x_start - x_start_pad) * scale
            oy_start = (y_start - y_start_pad) * scale
            ox_end = ox_start + (x_end - x_start) * scale
            oy_end = oy_start + (y_end - y_start) * scale

            # Paste into output
            out_x_start = x_start * scale
            out_y_start = y_start * scale
            out_x_end = x_end * scale
            out_y_end = y_end * scale

            output[:, :, out_y_start:out_y_end, out_x_start:out_x_end] = \
                tile_output[:, :, oy_start:oy_end, ox_start:ox_end]
            tile_weight[:, :, out_y_start:out_y_end, out_x_start:out_x_end] = 1.0

            count += 1
            if total > 1:
                print(f"[Upscale] Tile {count}/{total}", flush=True)

            # Free VRAM
            del tile_input, tile_output
            if device == 'cuda':
                torch.cuda.empty_cache()

    return output.clamp(0, 1)


def resize_with_mode(img, target_w, target_h, mode, cv2):
    """Resize image to target dimensions using the specified mode."""
    h, w = img.shape[:2]

    if mode == 'stretch':
        # Stretch: directly resize, ignoring aspect ratio
        return cv2.resize(img, (target_w, target_h), interpolation=cv2.INTER_LANCZOS4)

    elif mode == 'crop':
        # Crop: resize to fill, then center-crop
        scale = max(target_w / w, target_h / h)
        new_w = int(w * scale)
        new_h = int(h * scale)
        resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
        # Center crop
        x_off = (new_w - target_w) // 2
        y_off = (new_h - target_h) // 2
        return resized[y_off:y_off + target_h, x_off:x_off + target_w]

    else:  # 'fit' (default)
        # Fit: resize to fit within bounds, preserving aspect ratio
        scale = min(target_w / w, target_h / h)
        new_w = int(w * scale)
        new_h = int(h * scale)
        resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)

        if new_w == target_w and new_h == target_h:
            return resized

        # Add black padding to fill exact target
        canvas = np.zeros((target_h, target_w, 3), dtype=np.uint8)
        x_off = (target_w - new_w) // 2
        y_off = (target_h - new_h) // 2
        canvas[y_off:y_off + new_h, x_off:x_off + new_w] = resized
        return canvas


def run(cfg):
    import cv2

    input_path = cfg['input']
    output_path = cfg['output']
    target_res = cfg.get('resolution', '4k').lower()
    model_dir = cfg.get('model_dir', '')
    tile_size = cfg.get('tile_size', 512)
    mode = cfg.get('mode', 'fit').lower()          # fit, stretch, crop
    orientation = cfg.get('orientation', 'landscape').lower()  # landscape, portrait

    # Validate input
    if not os.path.exists(input_path):
        print(f"[Upscale] ERROR: Input not found: {input_path}", file=sys.stderr, flush=True)
        return False

    # Determine target resolution
    if target_res not in RESOLUTIONS:
        print(f"[Upscale] ERROR: Unknown resolution '{target_res}'. Use: 1080p, 2k, 4k",
              file=sys.stderr, flush=True)
        return False

    target_w, target_h = RESOLUTIONS[target_res]

    # Apply orientation
    if orientation == 'portrait':
        target_w, target_h = target_h, target_w
        print(f"[Upscale] Portrait orientation: {target_w}×{target_h}", flush=True)

    # Device
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"[Upscale] Device: {device}", flush=True)

    # Download + load model
    model_path = download_model(model_dir)
    if not os.path.exists(model_path):
        print("[Upscale] ERROR: Model file not found", file=sys.stderr, flush=True)
        return False

    model = load_model(model_path, device)

    # Read input image
    print(f"[Upscale] Reading: {os.path.basename(input_path)}", flush=True)
    img = imread_unicode(input_path)
    if img is None:
        print("[Upscale] ERROR: Cannot read image", file=sys.stderr, flush=True)
        return False

    h, w = img.shape[:2]
    print(f"[Upscale] Input size: {w}×{h}", flush=True)
    print(f"[Upscale] Target: {target_res} ({target_w}×{target_h}) | Mode: {mode}", flush=True)

    # Convert to tensor
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_tensor = torch.from_numpy(img_rgb).float() / 255.0
    img_tensor = img_tensor.permute(2, 0, 1).unsqueeze(0)

    # Upscale with tiling
    print("[Upscale] Upscaling with NMKD-Siax (4x)...", flush=True)
    if w <= tile_size and h <= tile_size:
        # Small enough to process in one pass
        with torch.no_grad():
            result_tensor = model(img_tensor.to(device)).cpu().clamp(0, 1)
    else:
        result_tensor = upscale_tile(model, img_tensor, tile_size=tile_size, device=device)

    # Convert back to numpy
    result_np = result_tensor[0].permute(1, 2, 0).numpy()
    result_np = (result_np * 255).astype(np.uint8)
    result_bgr = cv2.cvtColor(result_np, cv2.COLOR_RGB2BGR)

    up_h, up_w = result_bgr.shape[:2]
    print(f"[Upscale] Upscaled size: {up_w}×{up_h}", flush=True)

    # Resize to exact target resolution using selected mode
    if up_w != target_w or up_h != target_h:
        print(f"[Upscale] Resizing ({mode}) to: {target_w}×{target_h}", flush=True)
        result_bgr = resize_with_mode(result_bgr, target_w, target_h, mode, cv2)

    # Save output
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    imwrite_unicode(output_path, result_bgr, [cv2.IMWRITE_PNG_COMPRESSION, 3])
    final_h, final_w = result_bgr.shape[:2]
    print(f"[Upscale] Done! Output: {final_w}×{final_h} → {output_path}", flush=True)

    # Cleanup
    del model, img_tensor, result_tensor
    if device == 'cuda':
        torch.cuda.empty_cache()

    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)

    try:
        ok = run(cfg)
        print("[Upscale] SUCCESS" if ok else "[Upscale] FAILED", flush=True)
        sys.exit(0 if ok else 1)
    except Exception as e:
        print(f"[Upscale] ERROR: {e}", file=sys.stderr, flush=True)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
