"""
Subtitle generation worker for non-blocking UI
"""
from PyQt6.QtCore import QThread, pyqtSignal
import os


class SubtitleWorker(QThread):
    """Worker thread for generating subtitles without blocking UI"""
    
    # Signals
    status_updated = pyqtSignal(str)
    progress_updated = pyqtSignal(int)
    subtitles_generated = pyqtSignal(list)  # List of subtitle segments
    error_occurred = pyqtSignal(str)
    finished = pyqtSignal()
    
    def __init__(self, audio_path, config):
        super().__init__()
        self.audio_path = audio_path
        self.config = config
        self.cancelled = False
        
    def cancel(self):
        """Cancel the subtitle generation"""
        self.cancelled = True
        
    def run(self):
        """Run subtitle generation in background thread"""
        try:
            self.status_updated.emit("🔄 Đang khởi tạo GPU Whisper...")
            self.progress_updated.emit(10)
            
            if self.cancelled:
                return
                
            # Check if audio file exists
            if not os.path.exists(self.audio_path):
                self.error_occurred.emit(f"File âm thanh không tồn tại: {self.audio_path}")
                return
                
            # Import and initialize whisper subtitle generator
            from whisper_subtitle import WhisperSubtitleGenerator
            generator = WhisperSubtitleGenerator()
            
            self.status_updated.emit("📥 Đang load GPU model...")
            self.progress_updated.emit(20)
            
            if self.cancelled:
                return
                
            # Load model
            if not generator.load_model():
                self.error_occurred.emit("❌ Không thể khởi tạo GPU Whisper model")
                return
                
            self.status_updated.emit("✅ GPU model loaded thành công!")
            self.progress_updated.emit(40)
            
            if self.cancelled:
                return
                
            # Apply settings from UI
            generator.config.font_size = self.config['font_size']
            generator.config.font_color = self.config['font_color']
            generator.config.outline_width = self.config['outline_width']
            generator.config.outline_color = self.config['outline_color']
            generator.config.background_color = self.config['background_color']
            
            # Convert position text to internal format
            position_map = {
                "Dưới cùng": "bottom",
                "Trên cùng": "top", 
                "Giữa màn hình": "center"
            }
            generator.config.position = position_map.get(self.config['position'], 'bottom')
            
            generator.config.margin_bottom = self.config['margin_bottom']
            generator.config.margin_top = self.config['margin_top']
            generator.config.max_width_ratio = self.config['max_width_ratio']
            generator.config.words_per_subtitle = self.config['words_per_subtitle']
            generator.config.overlap_duration = self.config['overlap_duration']
            
            self.status_updated.emit("Đang phân tích âm thanh với GPU...")
            self.progress_updated.emit(60)
            
            if self.cancelled:
                return
                
            # Generate subtitles
            segments = generator.generate_subtitles(self.audio_path)
            
            self.progress_updated.emit(90)
            
            if self.cancelled:
                return
                
            if segments:
                self.status_updated.emit(f"✅ Đã tạo {len(segments)} phân đoạn phụ đề")
                self.progress_updated.emit(100)
                
                # Validate segments before emitting
                print(f"🔍 SubtitleWorker: Validating {len(segments)} segments before emission")
                valid_segments = []
                for i, seg in enumerate(segments):
                    if hasattr(seg, 'start') and hasattr(seg, 'end') and hasattr(seg, 'text'):
                        if seg.text and seg.text.strip():
                            valid_segments.append(seg)
                        else:
                            print(f"⚠️  Skipping empty segment {i+1}")
                    else:
                        print(f"❌ Invalid segment {i+1}: missing attributes")
                
                if valid_segments:
                    print(f"🎉 SubtitleWorker: Emitting {len(valid_segments)} valid subtitle segments")
                    self.subtitles_generated.emit(valid_segments)
                    
                    # Enhanced debug logging
                    print(f"✅ SubtitleWorker: Subtitle segments summary:")
                    total_duration = valid_segments[-1].end - valid_segments[0].start if valid_segments else 0
                    for i, seg in enumerate(valid_segments[:5]):  # Log first 5 segments
                        print(f"  [{i+1:2d}] {seg.start:6.3f}s - {seg.end:6.3f}s ({seg.end-seg.start:5.2f}s): '{seg.text[:40]}...'")
                    if len(valid_segments) > 5:
                        print(f"  ... and {len(valid_segments) - 5} more segments")
                    print(f"  📊 Total coverage: {total_duration:.1f}s")
                else:
                    print(f"❌ No valid segments to emit!")
                    self.error_occurred.emit("Không tạo được phụ đề hợp lệ từ audio")
                    
            else:
                self.error_occurred.emit("❌ Không tạo được phụ đề từ audio")
                
        except Exception as e:
            self.error_occurred.emit(f"Lỗi tạo phụ đề: {str(e)}")
        finally:
            # Ensure thread finishes properly
            self.finished.emit()
            # Clean up thread properly
            self.quit()
            self.wait()