#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SadTalker Lip-Sync inference wrapper.
Downloads models from HuggingFace and generates talking head video.
"""
import argparse, json, sys, os, shutil, glob


def load_config(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


def download_models(checkpoints_dir):
    """Download SadTalker checkpoints from GitHub Releases."""
    os.makedirs(checkpoints_dir, exist_ok=True)

    # Check if already downloaded
    marker = os.path.join(checkpoints_dir, "SadTalker_V0.0.2_256.safetensors")
    if os.path.exists(marker):
        print("[SadTalker] Models already downloaded.", flush=True)
        return True

    import urllib.request

    BASE = "https://github.com/OpenTalker/SadTalker/releases/download/v0.0.2-rc"
    files = [
        "SadTalker_V0.0.2_256.safetensors",
        "SadTalker_V0.0.2_512.safetensors",
        "mapping_00109-model.pth.tar",
        "mapping_00229-model.pth.tar",
    ]

    for fname in files:
        dest = os.path.join(checkpoints_dir, fname)
        if os.path.exists(dest):
            print(f"[SadTalker] {fname} already exists, skip.", flush=True)
            continue
        url = f"{BASE}/{fname}"
        print(f"[SadTalker] Downloading {fname}...", flush=True)
        try:
            urllib.request.urlretrieve(url, dest)
            print(f"[SadTalker] Downloaded {fname} OK", flush=True)
        except Exception as e:
            print(f"[SadTalker] Failed to download {fname}: {e}", file=sys.stderr, flush=True)
            return False

    print("[SadTalker] All models ready!", flush=True)
    return True


def run_inference(cfg):
    """Run SadTalker inference."""
    source_image = cfg['video_path']  # image or video
    audio_path = cfg['audio_path']
    output_path = cfg['output_path']
    sadtalker_dir = os.path.normpath(cfg.get('sadtalker_dir', ''))
    checkpoints_dir = os.path.join(sadtalker_dir, "checkpoints")

    # Validate inputs
    for label, p in [("Image/Video", source_image), ("Audio", audio_path)]:
        if not os.path.exists(p):
            print(f"[SadTalker] ERROR: {label} not found: {p}", file=sys.stderr, flush=True)
            return False

    # Ensure models are downloaded
    print("[SadTalker] Checking models...", flush=True)
    if not download_models(checkpoints_dir):
        return False

    # Add sadtalker dir to sys.path
    if sadtalker_dir not in sys.path:
        sys.path.insert(0, sadtalker_dir)

    # Change working directory
    original_cwd = os.getcwd()
    os.chdir(sadtalker_dir)

    try:
        print("[SadTalker] Loading modules...", flush=True)
        from src.utils.preprocess import CropAndExtract
        from src.test_audio2coeff import Audio2Coeff
        from src.facerender.animate import AnimateFromCoeff
        from src.generate_batch import get_data
        from src.generate_facerender_batch import get_facerender_data
        from src.utils.init_path import init_path

        import torch
        device = "cuda" if torch.cuda.is_available() else "cpu"
        size = 256

        # Init paths
        sadtalker_paths = init_path(
            checkpoints_dir,
            os.path.join(sadtalker_dir, 'src', 'config'),
            size, False, 'full'
        )

        # Init models
        print("[SadTalker] Loading models... (first time may take ~30s)", flush=True)
        preprocess_model = CropAndExtract(sadtalker_paths, device)
        audio_to_coeff = Audio2Coeff(sadtalker_paths, device)
        animate_from_coeff = AnimateFromCoeff(sadtalker_paths, device)

        # Create temp result dir
        from time import strftime
        save_dir = os.path.join(sadtalker_dir, "results", strftime("%Y_%m_%d_%H.%M.%S"))
        os.makedirs(save_dir, exist_ok=True)

        # Step 1: Extract 3DMM from source image
        first_frame_dir = os.path.join(save_dir, 'first_frame_dir')
        os.makedirs(first_frame_dir, exist_ok=True)
        print("[SadTalker] Extracting face features...", flush=True)

        first_coeff_path, crop_pic_path, crop_info = preprocess_model.generate(
            source_image, first_frame_dir, 'full',
            source_image_flag=True, pic_size=size
        )

        if first_coeff_path is None:
            print("[SadTalker] ERROR: Cannot detect face in image", file=sys.stderr, flush=True)
            return False

        # Step 2: Audio to coefficients
        print("[SadTalker] Processing audio...", flush=True)
        batch = get_data(first_coeff_path, audio_path, device, ref_eyeblink_coeff_path=None, still=True)
        coeff_path = audio_to_coeff.generate(batch, save_dir, 0, None)

        # Step 3: Generate video
        print("[SadTalker] Generating video...", flush=True)
        data = get_facerender_data(
            coeff_path, crop_pic_path, first_coeff_path, audio_path,
            batch_size=2,
            input_yaw_list=None, input_pitch_list=None, input_roll_list=None,
            expression_scale=1.0, still_mode=True, preprocess='full', size=size
        )

        result = animate_from_coeff.generate(
            data, save_dir, source_image, crop_info,
            enhancer=None, background_enhancer=None,
            preprocess='full', img_size=size
        )

        # Copy result
        output_dir = os.path.dirname(os.path.abspath(output_path))
        os.makedirs(output_dir, exist_ok=True)

        if result and os.path.exists(result):
            shutil.copy2(result, output_path)
            print(f"[SadTalker] Done! Output: {output_path}", flush=True)
        else:
            # Check for generated mp4
            final_mp4 = save_dir + '.mp4'
            if os.path.exists(final_mp4):
                shutil.copy2(final_mp4, output_path)
                print(f"[SadTalker] Done! Output: {output_path}", flush=True)
            else:
                print("[SadTalker] ERROR: No output video generated", file=sys.stderr, flush=True)
                return False

        # Cleanup temp
        try:
            if os.path.isdir(save_dir):
                shutil.rmtree(save_dir)
            final_mp4 = save_dir + '.mp4'
            if os.path.exists(final_mp4):
                os.remove(final_mp4)
        except Exception:
            pass

        return True

    except Exception as e:
        import traceback
        print(f"[SadTalker] ERROR: {e}", file=sys.stderr, flush=True)
        traceback.print_exc()
        return False
    finally:
        os.chdir(original_cwd)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)

    mode = cfg.get('mode', 'inference')
    if mode == 'download':
        sadtalker_dir = os.path.normpath(cfg.get('sadtalker_dir', ''))
        checkpoints_dir = os.path.join(sadtalker_dir, "checkpoints")
        ok = download_models(checkpoints_dir)
    else:
        ok = run_inference(cfg)

    print("[SadTalker] SUCCESS" if ok else "[SadTalker] FAILED", flush=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
